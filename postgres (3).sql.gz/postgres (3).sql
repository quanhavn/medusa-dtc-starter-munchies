-- Adminer 4.8.1 PostgreSQL 17.2 (Debian 17.2-1.pgdg120+1) dump





















































TRUNCATE "order_payment_collection";
INSERT INTO "order_payment_collection" ("order_id", "payment_collection_id", "id", "created_at", "updated_at", "deleted_at") VALUES
('order_01JH3BR6A4S3PYPT5CFSE90E6A',	'pay_col_01JH3BQY137956GNNAR1EQ66F9',	'ordpay_01JH3BR6BKPSYH70J5A1D7YD6X',	'2025-01-08 16:25:20+00',	'2025-01-08 16:25:20+00',	NULL),
('order_01JH3BZ2X4DGS0QZDE51PJG02A',	'pay_col_01JH3BYWZVH3WQ51RHJXMQZ59H',	'ordpay_01JH3BZ2Y91PE7RJKND5VCPAYJ',	'2025-01-08 16:29:06+00',	'2025-01-08 16:29:06+00',	NULL);








































































ALTER TABLE ONLY "public"."application_method_buy_rules" ADD CONSTRAINT "application_method_buy_rules_application_method_id_foreign" FOREIGN KEY (application_method_id) REFERENCES promotion_application_method(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."application_method_buy_rules" ADD CONSTRAINT "application_method_buy_rules_promotion_rule_id_foreign" FOREIGN KEY (promotion_rule_id) REFERENCES promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."application_method_target_rules" ADD CONSTRAINT "application_method_target_rules_application_method_id_foreign" FOREIGN KEY (application_method_id) REFERENCES promotion_application_method(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."application_method_target_rules" ADD CONSTRAINT "application_method_target_rules_promotion_rule_id_foreign" FOREIGN KEY (promotion_rule_id) REFERENCES promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."capture" ADD CONSTRAINT "capture_payment_id_foreign" FOREIGN KEY (payment_id) REFERENCES payment(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart" ADD CONSTRAINT "cart_billing_address_id_foreign" FOREIGN KEY (billing_address_id) REFERENCES cart_address(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;
ALTER TABLE ONLY "public"."cart" ADD CONSTRAINT "cart_shipping_address_id_foreign" FOREIGN KEY (shipping_address_id) REFERENCES cart_address(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart_line_item" ADD CONSTRAINT "cart_line_item_cart_id_foreign" FOREIGN KEY (cart_id) REFERENCES cart(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart_line_item_adjustment" ADD CONSTRAINT "cart_line_item_adjustment_item_id_foreign" FOREIGN KEY (item_id) REFERENCES cart_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart_line_item_tax_line" ADD CONSTRAINT "cart_line_item_tax_line_item_id_foreign" FOREIGN KEY (item_id) REFERENCES cart_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart_shipping_method" ADD CONSTRAINT "cart_shipping_method_cart_id_foreign" FOREIGN KEY (cart_id) REFERENCES cart(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart_shipping_method_adjustment" ADD CONSTRAINT "cart_shipping_method_adjustment_shipping_method_id_foreign" FOREIGN KEY (shipping_method_id) REFERENCES cart_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart_shipping_method_tax_line" ADD CONSTRAINT "cart_shipping_method_tax_line_shipping_method_id_foreign" FOREIGN KEY (shipping_method_id) REFERENCES cart_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."customer_address" ADD CONSTRAINT "customer_address_customer_id_foreign" FOREIGN KEY (customer_id) REFERENCES customer(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."customer_group_customer" ADD CONSTRAINT "customer_group_customer_customer_group_id_foreign" FOREIGN KEY (customer_group_id) REFERENCES customer_group(id) ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."customer_group_customer" ADD CONSTRAINT "customer_group_customer_customer_id_foreign" FOREIGN KEY (customer_id) REFERENCES customer(id) ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."fulfillment" ADD CONSTRAINT "fulfillment_delivery_address_id_foreign" FOREIGN KEY (delivery_address_id) REFERENCES fulfillment_address(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."fulfillment" ADD CONSTRAINT "fulfillment_provider_id_foreign" FOREIGN KEY (provider_id) REFERENCES fulfillment_provider(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;
ALTER TABLE ONLY "public"."fulfillment" ADD CONSTRAINT "fulfillment_shipping_option_id_foreign" FOREIGN KEY (shipping_option_id) REFERENCES shipping_option(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."fulfillment_item" ADD CONSTRAINT "fulfillment_item_fulfillment_id_foreign" FOREIGN KEY (fulfillment_id) REFERENCES fulfillment(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."fulfillment_label" ADD CONSTRAINT "fulfillment_label_fulfillment_id_foreign" FOREIGN KEY (fulfillment_id) REFERENCES fulfillment(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."geo_zone" ADD CONSTRAINT "geo_zone_service_zone_id_foreign" FOREIGN KEY (service_zone_id) REFERENCES service_zone(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."inventory_level" ADD CONSTRAINT "inventory_level_inventory_item_id_foreign" FOREIGN KEY (inventory_item_id) REFERENCES inventory_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."notification" ADD CONSTRAINT "notification_provider_id_foreign" FOREIGN KEY (provider_id) REFERENCES notification_provider(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order" ADD CONSTRAINT "order_billing_address_id_foreign" FOREIGN KEY (billing_address_id) REFERENCES order_address(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."order" ADD CONSTRAINT "order_shipping_address_id_foreign" FOREIGN KEY (shipping_address_id) REFERENCES order_address(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_change" ADD CONSTRAINT "order_change_order_id_foreign" FOREIGN KEY (order_id) REFERENCES "order"(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_change_action" ADD CONSTRAINT "order_change_action_order_change_id_foreign" FOREIGN KEY (order_change_id) REFERENCES order_change(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_item" ADD CONSTRAINT "order_item_item_id_foreign" FOREIGN KEY (item_id) REFERENCES order_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."order_item" ADD CONSTRAINT "order_item_order_id_foreign" FOREIGN KEY (order_id) REFERENCES "order"(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_line_item" ADD CONSTRAINT "order_line_item_totals_id_foreign" FOREIGN KEY (totals_id) REFERENCES order_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_line_item_adjustment" ADD CONSTRAINT "order_line_item_adjustment_item_id_foreign" FOREIGN KEY (item_id) REFERENCES order_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_line_item_tax_line" ADD CONSTRAINT "order_line_item_tax_line_item_id_foreign" FOREIGN KEY (item_id) REFERENCES order_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_shipping" ADD CONSTRAINT "order_shipping_order_id_foreign" FOREIGN KEY (order_id) REFERENCES "order"(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_shipping_method_adjustment" ADD CONSTRAINT "order_shipping_method_adjustment_shipping_method_id_foreign" FOREIGN KEY (shipping_method_id) REFERENCES order_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_shipping_method_tax_line" ADD CONSTRAINT "order_shipping_method_tax_line_shipping_method_id_foreign" FOREIGN KEY (shipping_method_id) REFERENCES order_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_transaction" ADD CONSTRAINT "order_transaction_order_id_foreign" FOREIGN KEY (order_id) REFERENCES "order"(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."payment" ADD CONSTRAINT "payment_payment_collection_id_foreign" FOREIGN KEY (payment_collection_id) REFERENCES payment_collection(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."payment_collection_payment_providers" ADD CONSTRAINT "payment_collection_payment_providers_payment_coll_aa276_foreign" FOREIGN KEY (payment_collection_id) REFERENCES payment_collection(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."payment_collection_payment_providers" ADD CONSTRAINT "payment_collection_payment_providers_payment_provider_id_foreig" FOREIGN KEY (payment_provider_id) REFERENCES payment_provider(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."price" ADD CONSTRAINT "price_price_list_id_foreign" FOREIGN KEY (price_list_id) REFERENCES price_list(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."price" ADD CONSTRAINT "price_price_set_id_foreign" FOREIGN KEY (price_set_id) REFERENCES price_set(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."price_list_rule" ADD CONSTRAINT "price_list_rule_price_list_id_foreign" FOREIGN KEY (price_list_id) REFERENCES price_list(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."price_rule" ADD CONSTRAINT "price_rule_price_id_foreign" FOREIGN KEY (price_id) REFERENCES price(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product" ADD CONSTRAINT "product_collection_id_foreign" FOREIGN KEY (collection_id) REFERENCES product_collection(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;
ALTER TABLE ONLY "public"."product" ADD CONSTRAINT "product_type_id_foreign" FOREIGN KEY (type_id) REFERENCES product_type(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_category" ADD CONSTRAINT "product_category_parent_category_id_foreign" FOREIGN KEY (parent_category_id) REFERENCES product_category(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_category_product" ADD CONSTRAINT "product_category_product_product_category_id_foreign" FOREIGN KEY (product_category_id) REFERENCES product_category(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."product_category_product" ADD CONSTRAINT "product_category_product_product_id_foreign" FOREIGN KEY (product_id) REFERENCES product(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_images" ADD CONSTRAINT "product_images_image_id_foreign" FOREIGN KEY (image_id) REFERENCES image(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."product_images" ADD CONSTRAINT "product_images_product_id_foreign" FOREIGN KEY (product_id) REFERENCES product(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_option" ADD CONSTRAINT "product_option_product_id_foreign" FOREIGN KEY (product_id) REFERENCES product(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_option_value" ADD CONSTRAINT "product_option_value_option_id_foreign" FOREIGN KEY (option_id) REFERENCES product_option(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_tags" ADD CONSTRAINT "product_tags_product_id_foreign" FOREIGN KEY (product_id) REFERENCES product(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."product_tags" ADD CONSTRAINT "product_tags_product_tag_id_foreign" FOREIGN KEY (product_tag_id) REFERENCES product_tag(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_variant" ADD CONSTRAINT "product_variant_product_id_foreign" FOREIGN KEY (product_id) REFERENCES product(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_variant_option" ADD CONSTRAINT "product_variant_option_option_value_id_foreign" FOREIGN KEY (option_value_id) REFERENCES product_option_value(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."product_variant_option" ADD CONSTRAINT "product_variant_option_variant_id_foreign" FOREIGN KEY (variant_id) REFERENCES product_variant(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."promotion" ADD CONSTRAINT "promotion_campaign_id_foreign" FOREIGN KEY (campaign_id) REFERENCES promotion_campaign(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."promotion_application_method" ADD CONSTRAINT "promotion_application_method_promotion_id_foreign" FOREIGN KEY (promotion_id) REFERENCES promotion(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."promotion_campaign_budget" ADD CONSTRAINT "promotion_campaign_budget_campaign_id_foreign" FOREIGN KEY (campaign_id) REFERENCES promotion_campaign(id) ON UPDATE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."promotion_promotion_rule" ADD CONSTRAINT "promotion_promotion_rule_promotion_id_foreign" FOREIGN KEY (promotion_id) REFERENCES promotion(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."promotion_promotion_rule" ADD CONSTRAINT "promotion_promotion_rule_promotion_rule_id_foreign" FOREIGN KEY (promotion_rule_id) REFERENCES promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."promotion_rule_value" ADD CONSTRAINT "promotion_rule_value_promotion_rule_id_foreign" FOREIGN KEY (promotion_rule_id) REFERENCES promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."provider_identity" ADD CONSTRAINT "provider_identity_auth_identity_id_foreign" FOREIGN KEY (auth_identity_id) REFERENCES auth_identity(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."refund" ADD CONSTRAINT "refund_payment_id_foreign" FOREIGN KEY (payment_id) REFERENCES payment(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."region_country" ADD CONSTRAINT "region_country_region_id_foreign" FOREIGN KEY (region_id) REFERENCES region(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."reservation_item" ADD CONSTRAINT "reservation_item_inventory_item_id_foreign" FOREIGN KEY (inventory_item_id) REFERENCES inventory_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."return_reason" ADD CONSTRAINT "return_reason_parent_return_reason_id_foreign" FOREIGN KEY (parent_return_reason_id) REFERENCES return_reason(id) NOT DEFERRABLE;

ALTER TABLE ONLY "public"."service_zone" ADD CONSTRAINT "service_zone_fulfillment_set_id_foreign" FOREIGN KEY (fulfillment_set_id) REFERENCES fulfillment_set(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."shipping_option" ADD CONSTRAINT "shipping_option_provider_id_foreign" FOREIGN KEY (provider_id) REFERENCES fulfillment_provider(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;
ALTER TABLE ONLY "public"."shipping_option" ADD CONSTRAINT "shipping_option_service_zone_id_foreign" FOREIGN KEY (service_zone_id) REFERENCES service_zone(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."shipping_option" ADD CONSTRAINT "shipping_option_shipping_option_type_id_foreign" FOREIGN KEY (shipping_option_type_id) REFERENCES shipping_option_type(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."shipping_option" ADD CONSTRAINT "shipping_option_shipping_profile_id_foreign" FOREIGN KEY (shipping_profile_id) REFERENCES shipping_profile(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."shipping_option_rule" ADD CONSTRAINT "shipping_option_rule_shipping_option_id_foreign" FOREIGN KEY (shipping_option_id) REFERENCES shipping_option(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."stock_location" ADD CONSTRAINT "stock_location_address_id_foreign" FOREIGN KEY (address_id) REFERENCES stock_location_address(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."store_currency" ADD CONSTRAINT "store_currency_store_id_foreign" FOREIGN KEY (store_id) REFERENCES store(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."tax_rate" ADD CONSTRAINT "FK_tax_rate_tax_region_id" FOREIGN KEY (tax_region_id) REFERENCES tax_region(id) ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."tax_rate_rule" ADD CONSTRAINT "FK_tax_rate_rule_tax_rate_id" FOREIGN KEY (tax_rate_id) REFERENCES tax_rate(id) ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."tax_region" ADD CONSTRAINT "FK_tax_region_parent_id" FOREIGN KEY (parent_id) REFERENCES tax_region(id) ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."tax_region" ADD CONSTRAINT "FK_tax_region_provider_id" FOREIGN KEY (provider_id) REFERENCES tax_provider(id) ON DELETE SET NULL NOT DEFERRABLE;

-- 2025-01-09 01:49:58.629997+00
