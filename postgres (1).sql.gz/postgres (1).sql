-- Adminer 4.8.1 PostgreSQL 17.2 (Debian 17.2-1.pgdg120+1) dump

\connect "postgres";

DROP TABLE IF EXISTS "api_key";
CREATE TABLE "public"."api_key" (
    "id" text NOT NULL,
    "token" text NOT NULL,
    "salt" text NOT NULL,
    "redacted" text NOT NULL,
    "title" text NOT NULL,
    "type" text NOT NULL,
    "last_used_at" timestamptz,
    "created_by" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "revoked_by" text,
    "revoked_at" timestamptz,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    CONSTRAINT "IDX_api_key_token_unique" UNIQUE ("token"),
    CONSTRAINT "api_key_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_api_key_type" ON "public"."api_key" USING btree ("type");


DROP TABLE IF EXISTS "application_method_buy_rules";
CREATE TABLE "public"."application_method_buy_rules" (
    "application_method_id" text NOT NULL,
    "promotion_rule_id" text NOT NULL,
    CONSTRAINT "application_method_buy_rules_pkey" PRIMARY KEY ("application_method_id", "promotion_rule_id")
) WITH (oids = false);


DROP TABLE IF EXISTS "application_method_target_rules";
CREATE TABLE "public"."application_method_target_rules" (
    "application_method_id" text NOT NULL,
    "promotion_rule_id" text NOT NULL,
    CONSTRAINT "application_method_target_rules_pkey" PRIMARY KEY ("application_method_id", "promotion_rule_id")
) WITH (oids = false);


DROP TABLE IF EXISTS "auth_identity";
CREATE TABLE "public"."auth_identity" (
    "id" text NOT NULL,
    "app_metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    CONSTRAINT "auth_identity_pkey" PRIMARY KEY ("id")
) WITH (oids = false);


DROP TABLE IF EXISTS "capture";
CREATE TABLE "public"."capture" (
    "id" text NOT NULL,
    "amount" numeric NOT NULL,
    "raw_amount" jsonb NOT NULL,
    "payment_id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "created_by" text,
    "metadata" jsonb,
    CONSTRAINT "capture_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_capture_deleted_at" ON "public"."capture" USING btree ("deleted_at");

CREATE INDEX "IDX_capture_payment_id" ON "public"."capture" USING btree ("payment_id");


DROP TABLE IF EXISTS "cart";
CREATE TABLE "public"."cart" (
    "id" text NOT NULL,
    "region_id" text,
    "customer_id" text,
    "sales_channel_id" text,
    "email" text,
    "currency_code" text NOT NULL,
    "shipping_address_id" text,
    "billing_address_id" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "completed_at" timestamptz,
    CONSTRAINT "cart_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_cart_billing_address_id" ON "public"."cart" USING btree ("billing_address_id");

CREATE INDEX "IDX_cart_currency_code" ON "public"."cart" USING btree ("currency_code");

CREATE INDEX "IDX_cart_customer_id" ON "public"."cart" USING btree ("customer_id");

CREATE INDEX "IDX_cart_deleted_at" ON "public"."cart" USING btree ("deleted_at");

CREATE INDEX "IDX_cart_region_id" ON "public"."cart" USING btree ("region_id");

CREATE INDEX "IDX_cart_sales_channel_id" ON "public"."cart" USING btree ("sales_channel_id");

CREATE INDEX "IDX_cart_shipping_address_id" ON "public"."cart" USING btree ("shipping_address_id");


DROP TABLE IF EXISTS "cart_address";
CREATE TABLE "public"."cart_address" (
    "id" text NOT NULL,
    "customer_id" text,
    "company" text,
    "first_name" text,
    "last_name" text,
    "address_1" text,
    "address_2" text,
    "city" text,
    "country_code" text,
    "province" text,
    "postal_code" text,
    "phone" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "cart_address_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_cart_address_deleted_at" ON "public"."cart_address" USING btree ("deleted_at");


DROP TABLE IF EXISTS "cart_line_item";
CREATE TABLE "public"."cart_line_item" (
    "id" text NOT NULL,
    "cart_id" text NOT NULL,
    "title" text NOT NULL,
    "subtitle" text,
    "thumbnail" text,
    "quantity" integer NOT NULL,
    "variant_id" text,
    "product_id" text,
    "product_title" text,
    "product_description" text,
    "product_subtitle" text,
    "product_type" text,
    "product_collection" text,
    "product_handle" text,
    "variant_sku" text,
    "variant_barcode" text,
    "variant_title" text,
    "variant_option_values" jsonb,
    "requires_shipping" boolean DEFAULT true NOT NULL,
    "is_discountable" boolean DEFAULT true NOT NULL,
    "is_tax_inclusive" boolean DEFAULT false NOT NULL,
    "compare_at_unit_price" numeric,
    "raw_compare_at_unit_price" jsonb,
    "unit_price" numeric NOT NULL,
    "raw_unit_price" jsonb NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "cart_line_item_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_cart_line_item_deleted_at" ON "public"."cart_line_item" USING btree ("deleted_at");

CREATE INDEX "IDX_line_item_cart_id" ON "public"."cart_line_item" USING btree ("cart_id");

CREATE INDEX "IDX_line_item_product_id" ON "public"."cart_line_item" USING btree ("product_id");

CREATE INDEX "IDX_line_item_variant_id" ON "public"."cart_line_item" USING btree ("variant_id");


DROP TABLE IF EXISTS "cart_line_item_adjustment";
CREATE TABLE "public"."cart_line_item_adjustment" (
    "id" text NOT NULL,
    "description" text,
    "promotion_id" text,
    "code" text,
    "amount" numeric NOT NULL,
    "raw_amount" jsonb NOT NULL,
    "provider_id" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "item_id" text,
    CONSTRAINT "cart_line_item_adjustment_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_adjustment_item_id" ON "public"."cart_line_item_adjustment" USING btree ("item_id");

CREATE INDEX "IDX_cart_line_item_adjustment_deleted_at" ON "public"."cart_line_item_adjustment" USING btree ("deleted_at");

CREATE INDEX "IDX_line_item_adjustment_promotion_id" ON "public"."cart_line_item_adjustment" USING btree ("promotion_id");


DROP TABLE IF EXISTS "cart_line_item_tax_line";
CREATE TABLE "public"."cart_line_item_tax_line" (
    "id" text NOT NULL,
    "description" text,
    "tax_rate_id" text,
    "code" text NOT NULL,
    "rate" numeric NOT NULL,
    "provider_id" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "item_id" text,
    CONSTRAINT "cart_line_item_tax_line_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_cart_line_item_tax_line_deleted_at" ON "public"."cart_line_item_tax_line" USING btree ("deleted_at");

CREATE INDEX "IDX_line_item_tax_line_tax_rate_id" ON "public"."cart_line_item_tax_line" USING btree ("tax_rate_id");

CREATE INDEX "IDX_tax_line_item_id" ON "public"."cart_line_item_tax_line" USING btree ("item_id");


DROP TABLE IF EXISTS "cart_payment_collection";
CREATE TABLE "public"."cart_payment_collection" (
    "cart_id" character varying(255) NOT NULL,
    "payment_collection_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "cart_payment_collection_pkey" PRIMARY KEY ("cart_id", "payment_collection_id")
) WITH (oids = false);

CREATE INDEX "IDX_cart_id_-4a39f6c9" ON "public"."cart_payment_collection" USING btree ("cart_id");

CREATE INDEX "IDX_deleted_at_-4a39f6c9" ON "public"."cart_payment_collection" USING btree ("deleted_at");

CREATE INDEX "IDX_id_-4a39f6c9" ON "public"."cart_payment_collection" USING btree ("id");

CREATE INDEX "IDX_payment_collection_id_-4a39f6c9" ON "public"."cart_payment_collection" USING btree ("payment_collection_id");


DROP TABLE IF EXISTS "cart_promotion";
CREATE TABLE "public"."cart_promotion" (
    "cart_id" character varying(255) NOT NULL,
    "promotion_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "cart_promotion_pkey" PRIMARY KEY ("cart_id", "promotion_id")
) WITH (oids = false);

CREATE INDEX "IDX_cart_id_-a9d4a70b" ON "public"."cart_promotion" USING btree ("cart_id");

CREATE INDEX "IDX_deleted_at_-a9d4a70b" ON "public"."cart_promotion" USING btree ("deleted_at");

CREATE INDEX "IDX_id_-a9d4a70b" ON "public"."cart_promotion" USING btree ("id");

CREATE INDEX "IDX_promotion_id_-a9d4a70b" ON "public"."cart_promotion" USING btree ("promotion_id");


DROP TABLE IF EXISTS "cart_shipping_method";
CREATE TABLE "public"."cart_shipping_method" (
    "id" text NOT NULL,
    "cart_id" text NOT NULL,
    "name" text NOT NULL,
    "description" jsonb,
    "amount" numeric NOT NULL,
    "raw_amount" jsonb NOT NULL,
    "is_tax_inclusive" boolean DEFAULT false NOT NULL,
    "shipping_option_id" text,
    "data" jsonb,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "cart_shipping_method_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_cart_shipping_method_deleted_at" ON "public"."cart_shipping_method" USING btree ("deleted_at");

CREATE INDEX "IDX_shipping_method_cart_id" ON "public"."cart_shipping_method" USING btree ("cart_id");

CREATE INDEX "IDX_shipping_method_option_id" ON "public"."cart_shipping_method" USING btree ("shipping_option_id");


DROP TABLE IF EXISTS "cart_shipping_method_adjustment";
CREATE TABLE "public"."cart_shipping_method_adjustment" (
    "id" text NOT NULL,
    "description" text,
    "promotion_id" text,
    "code" text,
    "amount" numeric NOT NULL,
    "raw_amount" jsonb NOT NULL,
    "provider_id" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "shipping_method_id" text,
    CONSTRAINT "cart_shipping_method_adjustment_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_adjustment_shipping_method_id" ON "public"."cart_shipping_method_adjustment" USING btree ("shipping_method_id");

CREATE INDEX "IDX_cart_shipping_method_adjustment_deleted_at" ON "public"."cart_shipping_method_adjustment" USING btree ("deleted_at");

CREATE INDEX "IDX_shipping_method_adjustment_promotion_id" ON "public"."cart_shipping_method_adjustment" USING btree ("promotion_id");


DROP TABLE IF EXISTS "cart_shipping_method_tax_line";
CREATE TABLE "public"."cart_shipping_method_tax_line" (
    "id" text NOT NULL,
    "description" text,
    "tax_rate_id" text,
    "code" text NOT NULL,
    "rate" numeric NOT NULL,
    "provider_id" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "shipping_method_id" text,
    CONSTRAINT "cart_shipping_method_tax_line_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_cart_shipping_method_tax_line_deleted_at" ON "public"."cart_shipping_method_tax_line" USING btree ("deleted_at");

CREATE INDEX "IDX_shipping_method_tax_line_tax_rate_id" ON "public"."cart_shipping_method_tax_line" USING btree ("tax_rate_id");

CREATE INDEX "IDX_tax_line_shipping_method_id" ON "public"."cart_shipping_method_tax_line" USING btree ("shipping_method_id");


DROP TABLE IF EXISTS "currency";
CREATE TABLE "public"."currency" (
    "code" text NOT NULL,
    "symbol" text NOT NULL,
    "symbol_native" text NOT NULL,
    "decimal_digits" integer DEFAULT '0' NOT NULL,
    "rounding" numeric DEFAULT '0' NOT NULL,
    "raw_rounding" jsonb NOT NULL,
    "name" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "currency_pkey" PRIMARY KEY ("code")
) WITH (oids = false);


DROP TABLE IF EXISTS "customer";
CREATE TABLE "public"."customer" (
    "id" text NOT NULL,
    "company_name" text,
    "first_name" text,
    "last_name" text,
    "email" text,
    "phone" text,
    "has_account" boolean DEFAULT false NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "created_by" text,
    CONSTRAINT "customer_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_customer_email_has_account_unique" ON "public"."customer" USING btree ("email", "has_account");


DROP TABLE IF EXISTS "customer_address";
CREATE TABLE "public"."customer_address" (
    "id" text NOT NULL,
    "customer_id" text NOT NULL,
    "address_name" text,
    "is_default_shipping" boolean DEFAULT false NOT NULL,
    "is_default_billing" boolean DEFAULT false NOT NULL,
    "company" text,
    "first_name" text,
    "last_name" text,
    "address_1" text,
    "address_2" text,
    "city" text,
    "country_code" text,
    "province" text,
    "postal_code" text,
    "phone" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    CONSTRAINT "customer_address_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_customer_address_customer_id" ON "public"."customer_address" USING btree ("customer_id");

CREATE INDEX "IDX_customer_address_unique_customer_billing" ON "public"."customer_address" USING btree ("customer_id");

CREATE INDEX "IDX_customer_address_unique_customer_shipping" ON "public"."customer_address" USING btree ("customer_id");


DROP TABLE IF EXISTS "customer_group";
CREATE TABLE "public"."customer_group" (
    "id" text NOT NULL,
    "name" text NOT NULL,
    "metadata" jsonb,
    "created_by" text,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "customer_group_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_customer_group_name" ON "public"."customer_group" USING btree ("name");

CREATE INDEX "IDX_customer_group_name_unique" ON "public"."customer_group" USING btree ("name");


DROP TABLE IF EXISTS "customer_group_customer";
CREATE TABLE "public"."customer_group_customer" (
    "id" text NOT NULL,
    "customer_id" text NOT NULL,
    "customer_group_id" text NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "created_by" text,
    CONSTRAINT "customer_group_customer_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_customer_group_customer_customer_id" ON "public"."customer_group_customer" USING btree ("customer_id");

CREATE INDEX "IDX_customer_group_customer_group_id" ON "public"."customer_group_customer" USING btree ("customer_group_id");


DROP TABLE IF EXISTS "fulfillment";
CREATE TABLE "public"."fulfillment" (
    "id" text NOT NULL,
    "location_id" text NOT NULL,
    "packed_at" timestamptz,
    "shipped_at" timestamptz,
    "delivered_at" timestamptz,
    "canceled_at" timestamptz,
    "data" jsonb,
    "provider_id" text,
    "shipping_option_id" text,
    "metadata" jsonb,
    "delivery_address_id" text,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "marked_shipped_by" text,
    "created_by" text,
    "requires_shipping" boolean DEFAULT true NOT NULL,
    CONSTRAINT "fulfillment_delivery_address_id_unique" UNIQUE ("delivery_address_id"),
    CONSTRAINT "fulfillment_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_fulfillment_deleted_at" ON "public"."fulfillment" USING btree ("deleted_at");

CREATE INDEX "IDX_fulfillment_location_id" ON "public"."fulfillment" USING btree ("location_id");

CREATE INDEX "IDX_fulfillment_provider_id" ON "public"."fulfillment" USING btree ("provider_id");

CREATE INDEX "IDX_fulfillment_shipping_option_id" ON "public"."fulfillment" USING btree ("shipping_option_id");


DROP TABLE IF EXISTS "fulfillment_address";
CREATE TABLE "public"."fulfillment_address" (
    "id" text NOT NULL,
    "company" text,
    "first_name" text,
    "last_name" text,
    "address_1" text,
    "address_2" text,
    "city" text,
    "country_code" text,
    "province" text,
    "postal_code" text,
    "phone" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "fulfillment_address_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_fulfillment_address_deleted_at" ON "public"."fulfillment_address" USING btree ("deleted_at");


DROP TABLE IF EXISTS "fulfillment_item";
CREATE TABLE "public"."fulfillment_item" (
    "id" text NOT NULL,
    "title" text NOT NULL,
    "sku" text NOT NULL,
    "barcode" text NOT NULL,
    "quantity" numeric NOT NULL,
    "raw_quantity" jsonb NOT NULL,
    "line_item_id" text,
    "inventory_item_id" text,
    "fulfillment_id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "fulfillment_item_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_fulfillment_item_deleted_at" ON "public"."fulfillment_item" USING btree ("deleted_at");

CREATE INDEX "IDX_fulfillment_item_fulfillment_id" ON "public"."fulfillment_item" USING btree ("fulfillment_id");

CREATE INDEX "IDX_fulfillment_item_inventory_item_id" ON "public"."fulfillment_item" USING btree ("inventory_item_id");

CREATE INDEX "IDX_fulfillment_item_line_item_id" ON "public"."fulfillment_item" USING btree ("line_item_id");


DROP TABLE IF EXISTS "fulfillment_label";
CREATE TABLE "public"."fulfillment_label" (
    "id" text NOT NULL,
    "tracking_number" text NOT NULL,
    "tracking_url" text NOT NULL,
    "label_url" text NOT NULL,
    "fulfillment_id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "fulfillment_label_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_fulfillment_label_deleted_at" ON "public"."fulfillment_label" USING btree ("deleted_at");

CREATE INDEX "IDX_fulfillment_label_fulfillment_id" ON "public"."fulfillment_label" USING btree ("fulfillment_id");


DROP TABLE IF EXISTS "fulfillment_provider";
CREATE TABLE "public"."fulfillment_provider" (
    "id" text NOT NULL,
    "is_enabled" boolean DEFAULT true NOT NULL,
    CONSTRAINT "fulfillment_provider_pkey" PRIMARY KEY ("id")
) WITH (oids = false);


DROP TABLE IF EXISTS "fulfillment_set";
CREATE TABLE "public"."fulfillment_set" (
    "id" text NOT NULL,
    "name" text NOT NULL,
    "type" text NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "fulfillment_set_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_fulfillment_set_deleted_at" ON "public"."fulfillment_set" USING btree ("deleted_at");

CREATE INDEX "IDX_fulfillment_set_name_unique" ON "public"."fulfillment_set" USING btree ("name");


DROP TABLE IF EXISTS "geo_zone";
CREATE TABLE "public"."geo_zone" (
    "id" text NOT NULL,
    "type" text DEFAULT 'country' NOT NULL,
    "country_code" text NOT NULL,
    "province_code" text,
    "city" text,
    "service_zone_id" text NOT NULL,
    "postal_expression" jsonb,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "geo_zone_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_geo_zone_city" ON "public"."geo_zone" USING btree ("city");

CREATE INDEX "IDX_geo_zone_country_code" ON "public"."geo_zone" USING btree ("country_code");

CREATE INDEX "IDX_geo_zone_deleted_at" ON "public"."geo_zone" USING btree ("deleted_at");

CREATE INDEX "IDX_geo_zone_province_code" ON "public"."geo_zone" USING btree ("province_code");

CREATE INDEX "IDX_geo_zone_service_zone_id" ON "public"."geo_zone" USING btree ("service_zone_id");


DROP TABLE IF EXISTS "image";
CREATE TABLE "public"."image" (
    "id" text NOT NULL,
    "url" text NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "image_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_product_image_deleted_at" ON "public"."image" USING btree ("deleted_at");

CREATE INDEX "IDX_product_image_url" ON "public"."image" USING btree ("url");


DROP TABLE IF EXISTS "inventory_item";
CREATE TABLE "public"."inventory_item" (
    "id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "sku" text,
    "origin_country" text,
    "hs_code" text,
    "mid_code" text,
    "material" text,
    "weight" integer,
    "length" integer,
    "height" integer,
    "width" integer,
    "requires_shipping" boolean DEFAULT true NOT NULL,
    "description" text,
    "title" text,
    "thumbnail" text,
    "metadata" jsonb,
    CONSTRAINT "inventory_item_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_inventory_item_deleted_at" ON "public"."inventory_item" USING btree ("deleted_at");

CREATE INDEX "IDX_inventory_item_sku_unique" ON "public"."inventory_item" USING btree ("sku");


DROP TABLE IF EXISTS "inventory_level";
CREATE TABLE "public"."inventory_level" (
    "id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "inventory_item_id" text NOT NULL,
    "location_id" text NOT NULL,
    "stocked_quantity" numeric DEFAULT '0' NOT NULL,
    "reserved_quantity" numeric DEFAULT '0' NOT NULL,
    "incoming_quantity" numeric DEFAULT '0' NOT NULL,
    "metadata" jsonb,
    "raw_stocked_quantity" jsonb,
    "raw_reserved_quantity" jsonb,
    "raw_incoming_quantity" jsonb,
    CONSTRAINT "inventory_level_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_inventory_level_deleted_at" ON "public"."inventory_level" USING btree ("deleted_at");

CREATE INDEX "IDX_inventory_level_inventory_item_id" ON "public"."inventory_level" USING btree ("inventory_item_id");

CREATE INDEX "IDX_inventory_level_item_location" ON "public"."inventory_level" USING btree ("inventory_item_id", "location_id");

CREATE INDEX "IDX_inventory_level_location_id" ON "public"."inventory_level" USING btree ("location_id");


DROP TABLE IF EXISTS "invite";
CREATE TABLE "public"."invite" (
    "id" text NOT NULL,
    "email" text NOT NULL,
    "accepted" boolean DEFAULT false NOT NULL,
    "token" text NOT NULL,
    "expires_at" timestamptz NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "invite_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_invite_deleted_at" ON "public"."invite" USING btree ("deleted_at");

CREATE INDEX "IDX_invite_email" ON "public"."invite" USING btree ("email");

CREATE INDEX "IDX_invite_token" ON "public"."invite" USING btree ("token");


DROP TABLE IF EXISTS "link_module_migrations";
DROP SEQUENCE IF EXISTS link_module_migrations_id_seq;
CREATE SEQUENCE link_module_migrations_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 START 16 CACHE 1;

CREATE TABLE "public"."link_module_migrations" (
    "id" integer DEFAULT nextval('link_module_migrations_id_seq') NOT NULL,
    "table_name" character varying(255) NOT NULL,
    "link_descriptor" jsonb DEFAULT '{}' NOT NULL,
    "created_at" timestamp DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "link_module_migrations_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "link_module_migrations_table_name_key" UNIQUE ("table_name")
) WITH (oids = false);


DROP TABLE IF EXISTS "location_fulfillment_provider";
CREATE TABLE "public"."location_fulfillment_provider" (
    "stock_location_id" character varying(255) NOT NULL,
    "fulfillment_provider_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "location_fulfillment_provider_pkey" PRIMARY KEY ("stock_location_id", "fulfillment_provider_id")
) WITH (oids = false);

CREATE INDEX "IDX_deleted_at_-1e5992737" ON "public"."location_fulfillment_provider" USING btree ("deleted_at");

CREATE INDEX "IDX_fulfillment_provider_id_-1e5992737" ON "public"."location_fulfillment_provider" USING btree ("fulfillment_provider_id");

CREATE INDEX "IDX_id_-1e5992737" ON "public"."location_fulfillment_provider" USING btree ("id");

CREATE INDEX "IDX_stock_location_id_-1e5992737" ON "public"."location_fulfillment_provider" USING btree ("stock_location_id");


DROP TABLE IF EXISTS "location_fulfillment_set";
CREATE TABLE "public"."location_fulfillment_set" (
    "stock_location_id" character varying(255) NOT NULL,
    "fulfillment_set_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "location_fulfillment_set_pkey" PRIMARY KEY ("stock_location_id", "fulfillment_set_id")
) WITH (oids = false);

CREATE INDEX "IDX_deleted_at_-e88adb96" ON "public"."location_fulfillment_set" USING btree ("deleted_at");

CREATE INDEX "IDX_fulfillment_set_id_-e88adb96" ON "public"."location_fulfillment_set" USING btree ("fulfillment_set_id");

CREATE INDEX "IDX_id_-e88adb96" ON "public"."location_fulfillment_set" USING btree ("id");

CREATE INDEX "IDX_stock_location_id_-e88adb96" ON "public"."location_fulfillment_set" USING btree ("stock_location_id");


DROP TABLE IF EXISTS "mikro_orm_migrations";
DROP SEQUENCE IF EXISTS mikro_orm_migrations_id_seq;
CREATE SEQUENCE mikro_orm_migrations_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 START 58 CACHE 1;

CREATE TABLE "public"."mikro_orm_migrations" (
    "id" integer DEFAULT nextval('mikro_orm_migrations_id_seq') NOT NULL,
    "name" character varying(255),
    "executed_at" timestamptz DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "mikro_orm_migrations_pkey" PRIMARY KEY ("id")
) WITH (oids = false);


DROP TABLE IF EXISTS "notification";
CREATE TABLE "public"."notification" (
    "id" text NOT NULL,
    "to" text NOT NULL,
    "channel" text NOT NULL,
    "template" text NOT NULL,
    "data" jsonb,
    "trigger_type" text,
    "resource_id" text,
    "resource_type" text,
    "receiver_id" text,
    "original_notification_id" text,
    "idempotency_key" text,
    "external_id" text,
    "provider_id" text,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "status" text DEFAULT 'pending' NOT NULL,
    CONSTRAINT "notification_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_notification_idempotency_key_unique" ON "public"."notification" USING btree ("idempotency_key");

CREATE INDEX "IDX_notification_provider_id" ON "public"."notification" USING btree ("provider_id");

CREATE INDEX "IDX_notification_receiver_id" ON "public"."notification" USING btree ("receiver_id");


DROP TABLE IF EXISTS "notification_provider";
CREATE TABLE "public"."notification_provider" (
    "id" text NOT NULL,
    "handle" text NOT NULL,
    "name" text NOT NULL,
    "is_enabled" boolean DEFAULT true NOT NULL,
    "channels" text[] DEFAULT '{}' NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "notification_provider_pkey" PRIMARY KEY ("id")
) WITH (oids = false);


DROP TABLE IF EXISTS "order";
DROP SEQUENCE IF EXISTS order_display_id_seq;
CREATE SEQUENCE order_display_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 START 2 CACHE 1;

CREATE TABLE "public"."order" (
    "id" text NOT NULL,
    "region_id" text,
    "display_id" integer DEFAULT nextval('order_display_id_seq'),
    "customer_id" text,
    "version" integer DEFAULT '1' NOT NULL,
    "sales_channel_id" text,
    "status" order_status_enum DEFAULT 'pending' NOT NULL,
    "is_draft_order" boolean DEFAULT false NOT NULL,
    "email" text,
    "currency_code" text NOT NULL,
    "shipping_address_id" text,
    "billing_address_id" text,
    "no_notification" boolean,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "canceled_at" timestamptz,
    CONSTRAINT "order_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_billing_address_id" ON "public"."order" USING btree ("billing_address_id");

CREATE INDEX "IDX_order_currency_code" ON "public"."order" USING btree ("currency_code");

CREATE INDEX "IDX_order_customer_id" ON "public"."order" USING btree ("customer_id");

CREATE INDEX "IDX_order_deleted_at" ON "public"."order" USING btree ("deleted_at");

CREATE INDEX "IDX_order_display_id" ON "public"."order" USING btree ("display_id");

CREATE INDEX "IDX_order_is_draft_order" ON "public"."order" USING btree ("is_draft_order");

CREATE INDEX "IDX_order_region_id" ON "public"."order" USING btree ("region_id");

CREATE INDEX "IDX_order_shipping_address_id" ON "public"."order" USING btree ("shipping_address_id");


DROP TABLE IF EXISTS "order_address";
CREATE TABLE "public"."order_address" (
    "id" text NOT NULL,
    "customer_id" text,
    "company" text,
    "first_name" text,
    "last_name" text,
    "address_1" text,
    "address_2" text,
    "city" text,
    "country_code" text,
    "province" text,
    "postal_code" text,
    "phone" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    CONSTRAINT "order_address_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_address_customer_id" ON "public"."order_address" USING btree ("customer_id");


DROP TABLE IF EXISTS "order_cart";
CREATE TABLE "public"."order_cart" (
    "order_id" character varying(255) NOT NULL,
    "cart_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "order_cart_pkey" PRIMARY KEY ("order_id", "cart_id")
) WITH (oids = false);

CREATE INDEX "IDX_cart_id_-71069c16" ON "public"."order_cart" USING btree ("cart_id");

CREATE INDEX "IDX_deleted_at_-71069c16" ON "public"."order_cart" USING btree ("deleted_at");

CREATE INDEX "IDX_id_-71069c16" ON "public"."order_cart" USING btree ("id");

CREATE INDEX "IDX_order_id_-71069c16" ON "public"."order_cart" USING btree ("order_id");


DROP TABLE IF EXISTS "order_change";
CREATE TABLE "public"."order_change" (
    "id" text NOT NULL,
    "order_id" text NOT NULL,
    "version" integer NOT NULL,
    "description" text,
    "status" text DEFAULT 'pending' NOT NULL,
    "internal_note" text,
    "created_by" text,
    "requested_by" text,
    "requested_at" timestamptz,
    "confirmed_by" text,
    "confirmed_at" timestamptz,
    "declined_by" text,
    "declined_reason" text,
    "metadata" jsonb,
    "declined_at" timestamptz,
    "canceled_by" text,
    "canceled_at" timestamptz,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "change_type" text,
    "deleted_at" timestamptz,
    "return_id" text,
    "claim_id" text,
    "exchange_id" text,
    CONSTRAINT "order_change_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_change_change_type" ON "public"."order_change" USING btree ("change_type");

CREATE INDEX "IDX_order_change_claim_id" ON "public"."order_change" USING btree ("claim_id");

CREATE INDEX "IDX_order_change_deleted_at" ON "public"."order_change" USING btree ("deleted_at");

CREATE INDEX "IDX_order_change_exchange_id" ON "public"."order_change" USING btree ("exchange_id");

CREATE INDEX "IDX_order_change_order_id" ON "public"."order_change" USING btree ("order_id");

CREATE INDEX "IDX_order_change_order_id_version" ON "public"."order_change" USING btree ("order_id", "version");

CREATE INDEX "IDX_order_change_return_id" ON "public"."order_change" USING btree ("return_id");

CREATE INDEX "IDX_order_change_status" ON "public"."order_change" USING btree ("status");


DROP TABLE IF EXISTS "order_change_action";
DROP SEQUENCE IF EXISTS order_change_action_ordering_seq;
CREATE SEQUENCE order_change_action_ordering_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."order_change_action" (
    "id" text NOT NULL,
    "order_id" text,
    "version" integer,
    "ordering" bigint DEFAULT nextval('order_change_action_ordering_seq') NOT NULL,
    "order_change_id" text,
    "reference" text,
    "reference_id" text,
    "action" text NOT NULL,
    "details" jsonb,
    "amount" numeric,
    "raw_amount" jsonb,
    "internal_note" text,
    "applied" boolean DEFAULT false NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "return_id" text,
    "claim_id" text,
    "exchange_id" text,
    CONSTRAINT "order_change_action_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_change_action_claim_id" ON "public"."order_change_action" USING btree ("claim_id");

CREATE INDEX "IDX_order_change_action_deleted_at" ON "public"."order_change_action" USING btree ("deleted_at");

CREATE INDEX "IDX_order_change_action_exchange_id" ON "public"."order_change_action" USING btree ("exchange_id");

CREATE INDEX "IDX_order_change_action_order_change_id" ON "public"."order_change_action" USING btree ("order_change_id");

CREATE INDEX "IDX_order_change_action_order_id" ON "public"."order_change_action" USING btree ("order_id");

CREATE INDEX "IDX_order_change_action_ordering" ON "public"."order_change_action" USING btree ("ordering");

CREATE INDEX "IDX_order_change_action_return_id" ON "public"."order_change_action" USING btree ("return_id");


DROP TABLE IF EXISTS "order_claim";
DROP SEQUENCE IF EXISTS order_claim_display_id_seq;
CREATE SEQUENCE order_claim_display_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."order_claim" (
    "id" text NOT NULL,
    "order_id" text NOT NULL,
    "return_id" text,
    "order_version" integer NOT NULL,
    "display_id" integer DEFAULT nextval('order_claim_display_id_seq') NOT NULL,
    "type" order_claim_type_enum NOT NULL,
    "no_notification" boolean,
    "refund_amount" numeric,
    "raw_refund_amount" jsonb,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "canceled_at" timestamptz,
    "created_by" text,
    CONSTRAINT "order_claim_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_claim_deleted_at" ON "public"."order_claim" USING btree ("deleted_at");

CREATE INDEX "IDX_order_claim_display_id" ON "public"."order_claim" USING btree ("display_id");

CREATE INDEX "IDX_order_claim_order_id" ON "public"."order_claim" USING btree ("order_id");

CREATE INDEX "IDX_order_claim_return_id" ON "public"."order_claim" USING btree ("return_id");


DROP TABLE IF EXISTS "order_claim_item";
CREATE TABLE "public"."order_claim_item" (
    "id" text NOT NULL,
    "claim_id" text NOT NULL,
    "item_id" text NOT NULL,
    "is_additional_item" boolean DEFAULT false NOT NULL,
    "reason" claim_reason_enum,
    "quantity" numeric NOT NULL,
    "raw_quantity" jsonb NOT NULL,
    "note" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "order_claim_item_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_claim_item_claim_id" ON "public"."order_claim_item" USING btree ("claim_id");

CREATE INDEX "IDX_order_claim_item_deleted_at" ON "public"."order_claim_item" USING btree ("deleted_at");

CREATE INDEX "IDX_order_claim_item_item_id" ON "public"."order_claim_item" USING btree ("item_id");


DROP TABLE IF EXISTS "order_claim_item_image";
CREATE TABLE "public"."order_claim_item_image" (
    "id" text NOT NULL,
    "claim_item_id" text NOT NULL,
    "url" text NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "order_claim_item_image_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_claim_item_image_claim_item_id" ON "public"."order_claim_item_image" USING btree ("claim_item_id");

CREATE INDEX "IDX_order_claim_item_image_deleted_at" ON "public"."order_claim_item_image" USING btree ("deleted_at");


DROP TABLE IF EXISTS "order_exchange";
DROP SEQUENCE IF EXISTS order_exchange_display_id_seq;
CREATE SEQUENCE order_exchange_display_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."order_exchange" (
    "id" text NOT NULL,
    "order_id" text NOT NULL,
    "return_id" text,
    "order_version" integer NOT NULL,
    "display_id" integer DEFAULT nextval('order_exchange_display_id_seq') NOT NULL,
    "no_notification" boolean,
    "allow_backorder" boolean DEFAULT false NOT NULL,
    "difference_due" numeric,
    "raw_difference_due" jsonb,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "canceled_at" timestamptz,
    "created_by" text,
    CONSTRAINT "order_exchange_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_exchange_deleted_at" ON "public"."order_exchange" USING btree ("deleted_at");

CREATE INDEX "IDX_order_exchange_display_id" ON "public"."order_exchange" USING btree ("display_id");

CREATE INDEX "IDX_order_exchange_order_id" ON "public"."order_exchange" USING btree ("order_id");

CREATE INDEX "IDX_order_exchange_return_id" ON "public"."order_exchange" USING btree ("return_id");


DROP TABLE IF EXISTS "order_exchange_item";
CREATE TABLE "public"."order_exchange_item" (
    "id" text NOT NULL,
    "exchange_id" text NOT NULL,
    "item_id" text NOT NULL,
    "quantity" numeric NOT NULL,
    "raw_quantity" jsonb NOT NULL,
    "note" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "order_exchange_item_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_exchange_item_deleted_at" ON "public"."order_exchange_item" USING btree ("deleted_at");

CREATE INDEX "IDX_order_exchange_item_exchange_id" ON "public"."order_exchange_item" USING btree ("exchange_id");

CREATE INDEX "IDX_order_exchange_item_item_id" ON "public"."order_exchange_item" USING btree ("item_id");


DROP TABLE IF EXISTS "order_fulfillment";
CREATE TABLE "public"."order_fulfillment" (
    "order_id" character varying(255) NOT NULL,
    "fulfillment_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "order_fulfillment_pkey" PRIMARY KEY ("order_id", "fulfillment_id")
) WITH (oids = false);

CREATE INDEX "IDX_deleted_at_-e8d2543e" ON "public"."order_fulfillment" USING btree ("deleted_at");

CREATE INDEX "IDX_fulfillment_id_-e8d2543e" ON "public"."order_fulfillment" USING btree ("fulfillment_id");

CREATE INDEX "IDX_id_-e8d2543e" ON "public"."order_fulfillment" USING btree ("id");

CREATE INDEX "IDX_order_id_-e8d2543e" ON "public"."order_fulfillment" USING btree ("order_id");


DROP TABLE IF EXISTS "order_item";
CREATE TABLE "public"."order_item" (
    "id" text NOT NULL,
    "order_id" text NOT NULL,
    "version" integer NOT NULL,
    "item_id" text NOT NULL,
    "quantity" numeric NOT NULL,
    "raw_quantity" jsonb NOT NULL,
    "fulfilled_quantity" numeric NOT NULL,
    "raw_fulfilled_quantity" jsonb NOT NULL,
    "shipped_quantity" numeric NOT NULL,
    "raw_shipped_quantity" jsonb NOT NULL,
    "return_requested_quantity" numeric NOT NULL,
    "raw_return_requested_quantity" jsonb NOT NULL,
    "return_received_quantity" numeric NOT NULL,
    "raw_return_received_quantity" jsonb NOT NULL,
    "return_dismissed_quantity" numeric NOT NULL,
    "raw_return_dismissed_quantity" jsonb NOT NULL,
    "written_off_quantity" numeric NOT NULL,
    "raw_written_off_quantity" jsonb NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "delivered_quantity" numeric DEFAULT '0' NOT NULL,
    "raw_delivered_quantity" jsonb NOT NULL,
    "unit_price" numeric,
    "raw_unit_price" jsonb,
    "compare_at_unit_price" numeric,
    "raw_compare_at_unit_price" jsonb,
    CONSTRAINT "order_item_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_item_deleted_at" ON "public"."order_item" USING btree ("deleted_at");

CREATE INDEX "IDX_order_item_item_id" ON "public"."order_item" USING btree ("item_id");

CREATE INDEX "IDX_order_item_order_id" ON "public"."order_item" USING btree ("order_id");

CREATE INDEX "IDX_order_item_order_id_version" ON "public"."order_item" USING btree ("order_id", "version");


DROP TABLE IF EXISTS "order_line_item";
CREATE TABLE "public"."order_line_item" (
    "id" text NOT NULL,
    "totals_id" text,
    "title" text NOT NULL,
    "subtitle" text,
    "thumbnail" text,
    "variant_id" text,
    "product_id" text,
    "product_title" text,
    "product_description" text,
    "product_subtitle" text,
    "product_type" text,
    "product_collection" text,
    "product_handle" text,
    "variant_sku" text,
    "variant_barcode" text,
    "variant_title" text,
    "variant_option_values" jsonb,
    "requires_shipping" boolean DEFAULT true NOT NULL,
    "is_discountable" boolean DEFAULT true NOT NULL,
    "is_tax_inclusive" boolean DEFAULT false NOT NULL,
    "compare_at_unit_price" numeric,
    "raw_compare_at_unit_price" jsonb,
    "unit_price" numeric NOT NULL,
    "raw_unit_price" jsonb NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "is_custom_price" boolean DEFAULT false NOT NULL,
    CONSTRAINT "order_line_item_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_line_item_product_id" ON "public"."order_line_item" USING btree ("product_id");

CREATE INDEX "IDX_order_line_item_variant_id" ON "public"."order_line_item" USING btree ("variant_id");


DROP TABLE IF EXISTS "order_line_item_adjustment";
CREATE TABLE "public"."order_line_item_adjustment" (
    "id" text NOT NULL,
    "description" text,
    "promotion_id" text,
    "code" text,
    "amount" numeric NOT NULL,
    "raw_amount" jsonb NOT NULL,
    "provider_id" text,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "item_id" text NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "order_line_item_adjustment_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_line_item_adjustment_item_id" ON "public"."order_line_item_adjustment" USING btree ("item_id");


DROP TABLE IF EXISTS "order_line_item_tax_line";
CREATE TABLE "public"."order_line_item_tax_line" (
    "id" text NOT NULL,
    "description" text,
    "tax_rate_id" text,
    "code" text NOT NULL,
    "rate" numeric NOT NULL,
    "raw_rate" jsonb NOT NULL,
    "provider_id" text,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "item_id" text NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "order_line_item_tax_line_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_line_item_tax_line_item_id" ON "public"."order_line_item_tax_line" USING btree ("item_id");


DROP TABLE IF EXISTS "order_payment_collection";
CREATE TABLE "public"."order_payment_collection" (
    "order_id" character varying(255) NOT NULL,
    "payment_collection_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "order_payment_collection_pkey" PRIMARY KEY ("order_id", "payment_collection_id")
) WITH (oids = false);

CREATE INDEX "IDX_deleted_at_f42b9949" ON "public"."order_payment_collection" USING btree ("deleted_at");

CREATE INDEX "IDX_id_f42b9949" ON "public"."order_payment_collection" USING btree ("id");

CREATE INDEX "IDX_order_id_f42b9949" ON "public"."order_payment_collection" USING btree ("order_id");

CREATE INDEX "IDX_payment_collection_id_f42b9949" ON "public"."order_payment_collection" USING btree ("payment_collection_id");

TRUNCATE "order_payment_collection";
INSERT INTO "order_payment_collection" ("order_id", "payment_collection_id", "id", "created_at", "updated_at", "deleted_at") VALUES
('order_01JH3BR6A4S3PYPT5CFSE90E6A',	'pay_col_01JH3BQY137956GNNAR1EQ66F9',	'ordpay_01JH3BR6BKPSYH70J5A1D7YD6X',	'2025-01-08 16:25:20+00',	'2025-01-08 16:25:20+00',	NULL),
('order_01JH3BZ2X4DGS0QZDE51PJG02A',	'pay_col_01JH3BYWZVH3WQ51RHJXMQZ59H',	'ordpay_01JH3BZ2Y91PE7RJKND5VCPAYJ',	'2025-01-08 16:29:06+00',	'2025-01-08 16:29:06+00',	NULL);

DROP TABLE IF EXISTS "order_promotion";
CREATE TABLE "public"."order_promotion" (
    "order_id" character varying(255) NOT NULL,
    "promotion_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "order_promotion_pkey" PRIMARY KEY ("order_id", "promotion_id")
) WITH (oids = false);

CREATE INDEX "IDX_deleted_at_-71518339" ON "public"."order_promotion" USING btree ("deleted_at");

CREATE INDEX "IDX_id_-71518339" ON "public"."order_promotion" USING btree ("id");

CREATE INDEX "IDX_order_id_-71518339" ON "public"."order_promotion" USING btree ("order_id");

CREATE INDEX "IDX_promotion_id_-71518339" ON "public"."order_promotion" USING btree ("promotion_id");


DROP TABLE IF EXISTS "order_shipping";
CREATE TABLE "public"."order_shipping" (
    "id" text NOT NULL,
    "order_id" text NOT NULL,
    "version" integer NOT NULL,
    "shipping_method_id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "return_id" text,
    "claim_id" text,
    "exchange_id" text,
    CONSTRAINT "order_shipping_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_shipping_claim_id" ON "public"."order_shipping" USING btree ("claim_id");

CREATE INDEX "IDX_order_shipping_deleted_at" ON "public"."order_shipping" USING btree ("deleted_at");

CREATE INDEX "IDX_order_shipping_exchange_id" ON "public"."order_shipping" USING btree ("exchange_id");

CREATE INDEX "IDX_order_shipping_item_id" ON "public"."order_shipping" USING btree ("shipping_method_id");

CREATE INDEX "IDX_order_shipping_order_id" ON "public"."order_shipping" USING btree ("order_id");

CREATE INDEX "IDX_order_shipping_order_id_version" ON "public"."order_shipping" USING btree ("order_id", "version");

CREATE INDEX "IDX_order_shipping_return_id" ON "public"."order_shipping" USING btree ("return_id");


DROP TABLE IF EXISTS "order_shipping_method";
CREATE TABLE "public"."order_shipping_method" (
    "id" text NOT NULL,
    "name" text NOT NULL,
    "description" jsonb,
    "amount" numeric NOT NULL,
    "raw_amount" jsonb NOT NULL,
    "is_tax_inclusive" boolean DEFAULT false NOT NULL,
    "shipping_option_id" text,
    "data" jsonb,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "is_custom_amount" boolean DEFAULT false NOT NULL,
    CONSTRAINT "order_shipping_method_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_shipping_method_shipping_option_id" ON "public"."order_shipping_method" USING btree ("shipping_option_id");


DROP TABLE IF EXISTS "order_shipping_method_adjustment";
CREATE TABLE "public"."order_shipping_method_adjustment" (
    "id" text NOT NULL,
    "description" text,
    "promotion_id" text,
    "code" text,
    "amount" numeric NOT NULL,
    "raw_amount" jsonb NOT NULL,
    "provider_id" text,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "shipping_method_id" text NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "order_shipping_method_adjustment_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_shipping_method_adjustment_shipping_method_id" ON "public"."order_shipping_method_adjustment" USING btree ("shipping_method_id");


DROP TABLE IF EXISTS "order_shipping_method_tax_line";
CREATE TABLE "public"."order_shipping_method_tax_line" (
    "id" text NOT NULL,
    "description" text,
    "tax_rate_id" text,
    "code" text NOT NULL,
    "rate" numeric NOT NULL,
    "raw_rate" jsonb NOT NULL,
    "provider_id" text,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "shipping_method_id" text NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "order_shipping_method_tax_line_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_shipping_method_tax_line_shipping_method_id" ON "public"."order_shipping_method_tax_line" USING btree ("shipping_method_id");


DROP TABLE IF EXISTS "order_summary";
CREATE TABLE "public"."order_summary" (
    "id" text NOT NULL,
    "order_id" text NOT NULL,
    "version" integer DEFAULT '1' NOT NULL,
    "totals" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "order_summary_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_summary_deleted_at" ON "public"."order_summary" USING btree ("deleted_at");

CREATE INDEX "IDX_order_summary_order_id_version" ON "public"."order_summary" USING btree ("order_id", "version");


DROP TABLE IF EXISTS "order_transaction";
CREATE TABLE "public"."order_transaction" (
    "id" text NOT NULL,
    "order_id" text NOT NULL,
    "version" integer DEFAULT '1' NOT NULL,
    "amount" numeric NOT NULL,
    "raw_amount" jsonb NOT NULL,
    "currency_code" text NOT NULL,
    "reference" text,
    "reference_id" text,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "return_id" text,
    "claim_id" text,
    "exchange_id" text,
    CONSTRAINT "order_transaction_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_order_transaction_claim_id" ON "public"."order_transaction" USING btree ("claim_id");

CREATE INDEX "IDX_order_transaction_currency_code" ON "public"."order_transaction" USING btree ("currency_code");

CREATE INDEX "IDX_order_transaction_exchange_id" ON "public"."order_transaction" USING btree ("exchange_id");

CREATE INDEX "IDX_order_transaction_order_id_version" ON "public"."order_transaction" USING btree ("order_id", "version");

CREATE INDEX "IDX_order_transaction_reference_id" ON "public"."order_transaction" USING btree ("reference_id");

CREATE INDEX "IDX_order_transaction_return_id" ON "public"."order_transaction" USING btree ("return_id");


DROP TABLE IF EXISTS "payment";
CREATE TABLE "public"."payment" (
    "id" text NOT NULL,
    "amount" numeric NOT NULL,
    "raw_amount" jsonb NOT NULL,
    "currency_code" text NOT NULL,
    "provider_id" text NOT NULL,
    "cart_id" text,
    "order_id" text,
    "customer_id" text,
    "data" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "captured_at" timestamptz,
    "canceled_at" timestamptz,
    "payment_collection_id" text NOT NULL,
    "payment_session_id" text NOT NULL,
    "metadata" jsonb,
    CONSTRAINT "payment_payment_session_id_unique" UNIQUE ("payment_session_id"),
    CONSTRAINT "payment_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_payment_deleted_at" ON "public"."payment" USING btree ("deleted_at");

CREATE INDEX "IDX_payment_payment_collection_id" ON "public"."payment" USING btree ("payment_collection_id");

CREATE INDEX "IDX_payment_payment_session_id" ON "public"."payment" USING btree ("payment_session_id");

CREATE INDEX "IDX_payment_provider_id" ON "public"."payment" USING btree ("provider_id");


DROP TABLE IF EXISTS "payment_collection";
CREATE TABLE "public"."payment_collection" (
    "id" text NOT NULL,
    "currency_code" text NOT NULL,
    "amount" numeric NOT NULL,
    "raw_amount" jsonb NOT NULL,
    "authorized_amount" numeric,
    "raw_authorized_amount" jsonb,
    "captured_amount" numeric,
    "raw_captured_amount" jsonb,
    "refunded_amount" numeric,
    "raw_refunded_amount" jsonb,
    "region_id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "completed_at" timestamptz,
    "status" text DEFAULT 'not_paid' NOT NULL,
    "metadata" jsonb,
    CONSTRAINT "payment_collection_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_payment_collection_deleted_at" ON "public"."payment_collection" USING btree ("deleted_at");

CREATE INDEX "IDX_payment_collection_region_id" ON "public"."payment_collection" USING btree ("region_id");


DROP TABLE IF EXISTS "payment_collection_payment_providers";
CREATE TABLE "public"."payment_collection_payment_providers" (
    "payment_collection_id" text NOT NULL,
    "payment_provider_id" text NOT NULL,
    CONSTRAINT "payment_collection_payment_providers_pkey" PRIMARY KEY ("payment_collection_id", "payment_provider_id")
) WITH (oids = false);


DROP TABLE IF EXISTS "payment_method_token";
CREATE TABLE "public"."payment_method_token" (
    "id" text NOT NULL,
    "provider_id" text NOT NULL,
    "data" jsonb,
    "name" text NOT NULL,
    "type_detail" text,
    "description_detail" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "payment_method_token_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_payment_method_token_deleted_at" ON "public"."payment_method_token" USING btree ("deleted_at");


DROP TABLE IF EXISTS "payment_provider";
CREATE TABLE "public"."payment_provider" (
    "id" text NOT NULL,
    "is_enabled" boolean DEFAULT true NOT NULL,
    CONSTRAINT "payment_provider_pkey" PRIMARY KEY ("id")
) WITH (oids = false);


DROP TABLE IF EXISTS "payment_session";
CREATE TABLE "public"."payment_session" (
    "id" text NOT NULL,
    "currency_code" text NOT NULL,
    "amount" numeric NOT NULL,
    "raw_amount" jsonb NOT NULL,
    "provider_id" text NOT NULL,
    "data" jsonb NOT NULL,
    "context" jsonb,
    "status" text DEFAULT 'pending' NOT NULL,
    "authorized_at" timestamptz,
    "payment_collection_id" text NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "payment_session_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_payment_session_deleted_at" ON "public"."payment_session" USING btree ("deleted_at");

CREATE INDEX "IDX_payment_session_payment_collection_id" ON "public"."payment_session" USING btree ("payment_collection_id");


DROP TABLE IF EXISTS "price";
CREATE TABLE "public"."price" (
    "id" text NOT NULL,
    "title" text,
    "price_set_id" text NOT NULL,
    "currency_code" text NOT NULL,
    "raw_amount" jsonb NOT NULL,
    "rules_count" integer DEFAULT '0' NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "price_list_id" text,
    "amount" numeric NOT NULL,
    "min_quantity" numeric,
    "max_quantity" numeric,
    CONSTRAINT "price_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_price_currency_code" ON "public"."price" USING btree ("currency_code");

CREATE INDEX "IDX_price_deleted_at" ON "public"."price" USING btree ("deleted_at");

CREATE INDEX "IDX_price_price_list_id" ON "public"."price" USING btree ("price_list_id");

CREATE INDEX "IDX_price_price_set_id" ON "public"."price" USING btree ("price_set_id");


DROP TABLE IF EXISTS "price_list";
CREATE TABLE "public"."price_list" (
    "id" text NOT NULL,
    "status" text DEFAULT 'draft' NOT NULL,
    "starts_at" timestamptz,
    "ends_at" timestamptz,
    "rules_count" integer DEFAULT '0' NOT NULL,
    "title" text NOT NULL,
    "description" text NOT NULL,
    "type" text DEFAULT 'sale' NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "price_list_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_price_list_deleted_at" ON "public"."price_list" USING btree ("deleted_at");


DROP TABLE IF EXISTS "price_list_rule";
CREATE TABLE "public"."price_list_rule" (
    "id" text NOT NULL,
    "price_list_id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "value" jsonb,
    "attribute" text DEFAULT '' NOT NULL,
    CONSTRAINT "price_list_rule_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_price_list_rule_deleted_at" ON "public"."price_list_rule" USING btree ("deleted_at");

CREATE INDEX "IDX_price_list_rule_price_list_id" ON "public"."price_list_rule" USING btree ("price_list_id");


DROP TABLE IF EXISTS "price_preference";
CREATE TABLE "public"."price_preference" (
    "id" text NOT NULL,
    "attribute" text NOT NULL,
    "value" text,
    "is_tax_inclusive" boolean DEFAULT false NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "price_preference_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_price_preference_attribute_value" ON "public"."price_preference" USING btree ("attribute", "value");

CREATE INDEX "IDX_price_preference_deleted_at" ON "public"."price_preference" USING btree ("deleted_at");


DROP TABLE IF EXISTS "price_rule";
CREATE TABLE "public"."price_rule" (
    "id" text NOT NULL,
    "value" text NOT NULL,
    "priority" integer DEFAULT '0' NOT NULL,
    "price_id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "attribute" text DEFAULT '' NOT NULL,
    CONSTRAINT "price_rule_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_price_rule_deleted_at" ON "public"."price_rule" USING btree ("deleted_at");

CREATE INDEX "IDX_price_rule_price_id_attribute_unique" ON "public"."price_rule" USING btree ("price_id", "attribute");


DROP TABLE IF EXISTS "price_set";
CREATE TABLE "public"."price_set" (
    "id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "price_set_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_price_set_deleted_at" ON "public"."price_set" USING btree ("deleted_at");


DROP TABLE IF EXISTS "product";
CREATE TABLE "public"."product" (
    "id" text NOT NULL,
    "title" text NOT NULL,
    "handle" text NOT NULL,
    "subtitle" text,
    "description" text,
    "is_giftcard" boolean DEFAULT false NOT NULL,
    "status" text NOT NULL,
    "thumbnail" text,
    "weight" text,
    "length" text,
    "height" text,
    "width" text,
    "origin_country" text,
    "hs_code" text,
    "mid_code" text,
    "material" text,
    "collection_id" text,
    "type_id" text,
    "discountable" boolean DEFAULT true NOT NULL,
    "external_id" text,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "metadata" jsonb,
    CONSTRAINT "product_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_product_collection_id" ON "public"."product" USING btree ("collection_id");

CREATE INDEX "IDX_product_deleted_at" ON "public"."product" USING btree ("deleted_at");

CREATE INDEX "IDX_product_handle_unique" ON "public"."product" USING btree ("handle");

CREATE INDEX "IDX_product_type_id" ON "public"."product" USING btree ("type_id");


DROP TABLE IF EXISTS "product_category";
CREATE TABLE "public"."product_category" (
    "id" text NOT NULL,
    "name" text NOT NULL,
    "description" text DEFAULT '' NOT NULL,
    "handle" text NOT NULL,
    "mpath" text NOT NULL,
    "is_active" boolean DEFAULT false NOT NULL,
    "is_internal" boolean DEFAULT false NOT NULL,
    "rank" integer DEFAULT '0' NOT NULL,
    "parent_category_id" text,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "metadata" jsonb,
    CONSTRAINT "product_category_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_category_handle_unique" ON "public"."product_category" USING btree ("handle");

CREATE INDEX "IDX_product_category_path" ON "public"."product_category" USING btree ("mpath");


DROP TABLE IF EXISTS "product_category_product";
CREATE TABLE "public"."product_category_product" (
    "product_id" text NOT NULL,
    "product_category_id" text NOT NULL,
    CONSTRAINT "product_category_product_pkey" PRIMARY KEY ("product_id", "product_category_id")
) WITH (oids = false);


DROP TABLE IF EXISTS "product_collection";
CREATE TABLE "public"."product_collection" (
    "id" text NOT NULL,
    "title" text NOT NULL,
    "handle" text NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "product_collection_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_collection_handle_unique" ON "public"."product_collection" USING btree ("handle");

CREATE INDEX "IDX_product_category_deleted_at" ON "public"."product_collection" USING btree ("deleted_at");

CREATE INDEX "IDX_product_collection_deleted_at" ON "public"."product_collection" USING btree ("deleted_at");


DROP TABLE IF EXISTS "product_images";
CREATE TABLE "public"."product_images" (
    "product_id" text NOT NULL,
    "image_id" text NOT NULL,
    CONSTRAINT "product_images_pkey" PRIMARY KEY ("product_id", "image_id")
) WITH (oids = false);


DROP TABLE IF EXISTS "product_option";
CREATE TABLE "public"."product_option" (
    "id" text NOT NULL,
    "title" text NOT NULL,
    "product_id" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "product_option_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_option_product_id_title_unique" ON "public"."product_option" USING btree ("product_id", "title");

CREATE INDEX "IDX_product_option_deleted_at" ON "public"."product_option" USING btree ("deleted_at");


DROP TABLE IF EXISTS "product_option_value";
CREATE TABLE "public"."product_option_value" (
    "id" text NOT NULL,
    "value" text NOT NULL,
    "option_id" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "product_option_value_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_option_value_option_id_unique" ON "public"."product_option_value" USING btree ("option_id", "value");

CREATE INDEX "IDX_product_option_value_deleted_at" ON "public"."product_option_value" USING btree ("deleted_at");


DROP TABLE IF EXISTS "product_sales_channel";
CREATE TABLE "public"."product_sales_channel" (
    "product_id" character varying(255) NOT NULL,
    "sales_channel_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "product_sales_channel_pkey" PRIMARY KEY ("product_id", "sales_channel_id")
) WITH (oids = false);

CREATE INDEX "IDX_deleted_at_20b454295" ON "public"."product_sales_channel" USING btree ("deleted_at");

CREATE INDEX "IDX_id_20b454295" ON "public"."product_sales_channel" USING btree ("id");

CREATE INDEX "IDX_product_id_20b454295" ON "public"."product_sales_channel" USING btree ("product_id");

CREATE INDEX "IDX_sales_channel_id_20b454295" ON "public"."product_sales_channel" USING btree ("sales_channel_id");


DROP TABLE IF EXISTS "product_tag";
CREATE TABLE "public"."product_tag" (
    "id" text NOT NULL,
    "value" text NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "product_tag_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_product_tag_deleted_at" ON "public"."product_tag" USING btree ("deleted_at");

CREATE INDEX "IDX_tag_value_unique" ON "public"."product_tag" USING btree ("value");


DROP TABLE IF EXISTS "product_tags";
CREATE TABLE "public"."product_tags" (
    "product_id" text NOT NULL,
    "product_tag_id" text NOT NULL,
    CONSTRAINT "product_tags_pkey" PRIMARY KEY ("product_id", "product_tag_id")
) WITH (oids = false);


DROP TABLE IF EXISTS "product_type";
CREATE TABLE "public"."product_type" (
    "id" text NOT NULL,
    "value" text NOT NULL,
    "metadata" json,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "product_type_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_product_type_deleted_at" ON "public"."product_type" USING btree ("deleted_at");

CREATE INDEX "IDX_type_value_unique" ON "public"."product_type" USING btree ("value");


DROP TABLE IF EXISTS "product_variant";
CREATE TABLE "public"."product_variant" (
    "id" text NOT NULL,
    "title" text NOT NULL,
    "sku" text,
    "barcode" text,
    "ean" text,
    "upc" text,
    "allow_backorder" boolean DEFAULT false NOT NULL,
    "manage_inventory" boolean DEFAULT true NOT NULL,
    "hs_code" text,
    "origin_country" text,
    "mid_code" text,
    "material" text,
    "weight" numeric,
    "length" numeric,
    "height" numeric,
    "width" numeric,
    "metadata" jsonb,
    "variant_rank" integer DEFAULT '0',
    "product_id" text,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "product_variant_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_product_variant_barcode_unique" ON "public"."product_variant" USING btree ("barcode");

CREATE INDEX "IDX_product_variant_deleted_at" ON "public"."product_variant" USING btree ("deleted_at");

CREATE INDEX "IDX_product_variant_ean_unique" ON "public"."product_variant" USING btree ("ean");

CREATE INDEX "IDX_product_variant_product_id" ON "public"."product_variant" USING btree ("product_id");

CREATE INDEX "IDX_product_variant_sku_unique" ON "public"."product_variant" USING btree ("sku");

CREATE INDEX "IDX_product_variant_upc_unique" ON "public"."product_variant" USING btree ("upc");


DROP TABLE IF EXISTS "product_variant_inventory_item";
CREATE TABLE "public"."product_variant_inventory_item" (
    "variant_id" character varying(255) NOT NULL,
    "inventory_item_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "required_quantity" integer DEFAULT '1' NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "product_variant_inventory_item_pkey" PRIMARY KEY ("variant_id", "inventory_item_id")
) WITH (oids = false);

CREATE INDEX "IDX_deleted_at_17b4c4e35" ON "public"."product_variant_inventory_item" USING btree ("deleted_at");

CREATE INDEX "IDX_id_17b4c4e35" ON "public"."product_variant_inventory_item" USING btree ("id");

CREATE INDEX "IDX_inventory_item_id_17b4c4e35" ON "public"."product_variant_inventory_item" USING btree ("inventory_item_id");

CREATE INDEX "IDX_variant_id_17b4c4e35" ON "public"."product_variant_inventory_item" USING btree ("variant_id");


DROP TABLE IF EXISTS "product_variant_option";
CREATE TABLE "public"."product_variant_option" (
    "variant_id" text NOT NULL,
    "option_value_id" text NOT NULL,
    CONSTRAINT "product_variant_option_pkey" PRIMARY KEY ("variant_id", "option_value_id")
) WITH (oids = false);


DROP TABLE IF EXISTS "product_variant_price_set";
CREATE TABLE "public"."product_variant_price_set" (
    "variant_id" character varying(255) NOT NULL,
    "price_set_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "product_variant_price_set_pkey" PRIMARY KEY ("variant_id", "price_set_id")
) WITH (oids = false);

CREATE INDEX "IDX_deleted_at_52b23597" ON "public"."product_variant_price_set" USING btree ("deleted_at");

CREATE INDEX "IDX_id_52b23597" ON "public"."product_variant_price_set" USING btree ("id");

CREATE INDEX "IDX_price_set_id_52b23597" ON "public"."product_variant_price_set" USING btree ("price_set_id");

CREATE INDEX "IDX_variant_id_52b23597" ON "public"."product_variant_price_set" USING btree ("variant_id");


DROP TABLE IF EXISTS "promotion";
CREATE TABLE "public"."promotion" (
    "id" text NOT NULL,
    "code" text NOT NULL,
    "campaign_id" text,
    "is_automatic" boolean DEFAULT false NOT NULL,
    "type" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "IDX_promotion_code_unique" UNIQUE ("code"),
    CONSTRAINT "promotion_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_promotion_code" ON "public"."promotion" USING btree ("code");

CREATE INDEX "IDX_promotion_type" ON "public"."promotion" USING btree ("type");


DROP TABLE IF EXISTS "promotion_application_method";
CREATE TABLE "public"."promotion_application_method" (
    "id" text NOT NULL,
    "value" numeric,
    "raw_value" jsonb NOT NULL,
    "max_quantity" numeric,
    "apply_to_quantity" numeric,
    "buy_rules_min_quantity" numeric,
    "type" text NOT NULL,
    "target_type" text NOT NULL,
    "allocation" text,
    "promotion_id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "currency_code" text,
    CONSTRAINT "promotion_application_method_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "promotion_application_method_promotion_id_unique" UNIQUE ("promotion_id")
) WITH (oids = false);

CREATE INDEX "IDX_application_method_allocation" ON "public"."promotion_application_method" USING btree ("allocation");

CREATE INDEX "IDX_application_method_target_type" ON "public"."promotion_application_method" USING btree ("target_type");

CREATE INDEX "IDX_application_method_type" ON "public"."promotion_application_method" USING btree ("type");

CREATE INDEX "IDX_promotion_application_method_currency_code" ON "public"."promotion_application_method" USING btree ("currency_code");


DROP TABLE IF EXISTS "promotion_campaign";
CREATE TABLE "public"."promotion_campaign" (
    "id" text NOT NULL,
    "name" text NOT NULL,
    "description" text,
    "campaign_identifier" text NOT NULL,
    "starts_at" timestamptz,
    "ends_at" timestamptz,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "promotion_campaign_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_promotion_campaign_campaign_identifier_unique" ON "public"."promotion_campaign" USING btree ("campaign_identifier");


DROP TABLE IF EXISTS "promotion_campaign_budget";
CREATE TABLE "public"."promotion_campaign_budget" (
    "id" text NOT NULL,
    "type" text NOT NULL,
    "campaign_id" text NOT NULL,
    "limit" numeric,
    "raw_limit" jsonb,
    "used" numeric DEFAULT '0' NOT NULL,
    "raw_used" jsonb NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "currency_code" text,
    CONSTRAINT "promotion_campaign_budget_campaign_id_unique" UNIQUE ("campaign_id"),
    CONSTRAINT "promotion_campaign_budget_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_campaign_budget_type" ON "public"."promotion_campaign_budget" USING btree ("type");


DROP TABLE IF EXISTS "promotion_promotion_rule";
CREATE TABLE "public"."promotion_promotion_rule" (
    "promotion_id" text NOT NULL,
    "promotion_rule_id" text NOT NULL,
    CONSTRAINT "promotion_promotion_rule_pkey" PRIMARY KEY ("promotion_id", "promotion_rule_id")
) WITH (oids = false);


DROP TABLE IF EXISTS "promotion_rule";
CREATE TABLE "public"."promotion_rule" (
    "id" text NOT NULL,
    "description" text,
    "attribute" text NOT NULL,
    "operator" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "promotion_rule_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_promotion_rule_attribute" ON "public"."promotion_rule" USING btree ("attribute");

CREATE INDEX "IDX_promotion_rule_operator" ON "public"."promotion_rule" USING btree ("operator");


DROP TABLE IF EXISTS "promotion_rule_value";
CREATE TABLE "public"."promotion_rule_value" (
    "id" text NOT NULL,
    "promotion_rule_id" text NOT NULL,
    "value" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "promotion_rule_value_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_promotion_rule_promotion_rule_value_id" ON "public"."promotion_rule_value" USING btree ("promotion_rule_id");


DROP TABLE IF EXISTS "provider_identity";
CREATE TABLE "public"."provider_identity" (
    "id" text NOT NULL,
    "entity_id" text NOT NULL,
    "provider" text NOT NULL,
    "auth_identity_id" text NOT NULL,
    "user_metadata" jsonb,
    "provider_metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    CONSTRAINT "IDX_provider_identity_provider_entity_id" UNIQUE ("entity_id", "provider"),
    CONSTRAINT "provider_identity_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_provider_identity_auth_identity_id" ON "public"."provider_identity" USING btree ("auth_identity_id");


DROP TABLE IF EXISTS "publishable_api_key_sales_channel";
CREATE TABLE "public"."publishable_api_key_sales_channel" (
    "publishable_key_id" character varying(255) NOT NULL,
    "sales_channel_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "publishable_api_key_sales_channel_pkey" PRIMARY KEY ("publishable_key_id", "sales_channel_id")
) WITH (oids = false);

CREATE INDEX "IDX_deleted_at_-1d67bae40" ON "public"."publishable_api_key_sales_channel" USING btree ("deleted_at");

CREATE INDEX "IDX_id_-1d67bae40" ON "public"."publishable_api_key_sales_channel" USING btree ("id");

CREATE INDEX "IDX_publishable_key_id_-1d67bae40" ON "public"."publishable_api_key_sales_channel" USING btree ("publishable_key_id");

CREATE INDEX "IDX_sales_channel_id_-1d67bae40" ON "public"."publishable_api_key_sales_channel" USING btree ("sales_channel_id");


DROP TABLE IF EXISTS "refund";
CREATE TABLE "public"."refund" (
    "id" text NOT NULL,
    "amount" numeric NOT NULL,
    "raw_amount" jsonb NOT NULL,
    "payment_id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "created_by" text,
    "metadata" jsonb,
    "refund_reason_id" text,
    "note" text,
    CONSTRAINT "refund_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_refund_deleted_at" ON "public"."refund" USING btree ("deleted_at");

CREATE INDEX "IDX_refund_payment_id" ON "public"."refund" USING btree ("payment_id");


DROP TABLE IF EXISTS "refund_reason";
CREATE TABLE "public"."refund_reason" (
    "id" text NOT NULL,
    "label" text NOT NULL,
    "description" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "refund_reason_pkey" PRIMARY KEY ("id")
) WITH (oids = false);


DROP TABLE IF EXISTS "region";
CREATE TABLE "public"."region" (
    "id" text NOT NULL,
    "name" text NOT NULL,
    "currency_code" text NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "automatic_taxes" boolean DEFAULT true NOT NULL,
    CONSTRAINT "region_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_region_deleted_at" ON "public"."region" USING btree ("deleted_at");


DROP TABLE IF EXISTS "region_country";
CREATE TABLE "public"."region_country" (
    "iso_2" text NOT NULL,
    "iso_3" text NOT NULL,
    "num_code" text NOT NULL,
    "name" text NOT NULL,
    "display_name" text NOT NULL,
    "region_id" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "IDX_region_country_region_id_iso_2_unique" UNIQUE ("region_id", "iso_2"),
    CONSTRAINT "region_country_pkey" PRIMARY KEY ("iso_2")
) WITH (oids = false);


DROP TABLE IF EXISTS "region_payment_provider";
CREATE TABLE "public"."region_payment_provider" (
    "region_id" character varying(255) NOT NULL,
    "payment_provider_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "region_payment_provider_pkey" PRIMARY KEY ("region_id", "payment_provider_id")
) WITH (oids = false);

CREATE INDEX "IDX_deleted_at_1c934dab0" ON "public"."region_payment_provider" USING btree ("deleted_at");

CREATE INDEX "IDX_id_1c934dab0" ON "public"."region_payment_provider" USING btree ("id");

CREATE INDEX "IDX_payment_provider_id_1c934dab0" ON "public"."region_payment_provider" USING btree ("payment_provider_id");

CREATE INDEX "IDX_region_id_1c934dab0" ON "public"."region_payment_provider" USING btree ("region_id");


DROP TABLE IF EXISTS "reservation_item";
CREATE TABLE "public"."reservation_item" (
    "id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "line_item_id" text,
    "location_id" text NOT NULL,
    "quantity" numeric NOT NULL,
    "external_id" text,
    "description" text,
    "created_by" text,
    "metadata" jsonb,
    "inventory_item_id" text NOT NULL,
    "allow_backorder" boolean DEFAULT false,
    "raw_quantity" jsonb,
    CONSTRAINT "reservation_item_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_reservation_item_deleted_at" ON "public"."reservation_item" USING btree ("deleted_at");

CREATE INDEX "IDX_reservation_item_inventory_item_id" ON "public"."reservation_item" USING btree ("inventory_item_id");

CREATE INDEX "IDX_reservation_item_line_item_id" ON "public"."reservation_item" USING btree ("line_item_id");

CREATE INDEX "IDX_reservation_item_location_id" ON "public"."reservation_item" USING btree ("location_id");


DROP TABLE IF EXISTS "return";
DROP SEQUENCE IF EXISTS return_display_id_seq;
CREATE SEQUENCE return_display_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."return" (
    "id" text NOT NULL,
    "order_id" text NOT NULL,
    "claim_id" text,
    "exchange_id" text,
    "order_version" integer NOT NULL,
    "display_id" integer DEFAULT nextval('return_display_id_seq') NOT NULL,
    "status" return_status_enum DEFAULT 'open' NOT NULL,
    "no_notification" boolean,
    "refund_amount" numeric,
    "raw_refund_amount" jsonb,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "received_at" timestamptz,
    "canceled_at" timestamptz,
    "location_id" text,
    "requested_at" timestamptz,
    "created_by" text,
    CONSTRAINT "return_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_return_claim_id" ON "public"."return" USING btree ("claim_id");

CREATE INDEX "IDX_return_display_id" ON "public"."return" USING btree ("display_id");

CREATE INDEX "IDX_return_exchange_id" ON "public"."return" USING btree ("exchange_id");

CREATE INDEX "IDX_return_order_id" ON "public"."return" USING btree ("order_id");


DROP TABLE IF EXISTS "return_fulfillment";
CREATE TABLE "public"."return_fulfillment" (
    "return_id" character varying(255) NOT NULL,
    "fulfillment_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "return_fulfillment_pkey" PRIMARY KEY ("return_id", "fulfillment_id")
) WITH (oids = false);

CREATE INDEX "IDX_deleted_at_-31ea43a" ON "public"."return_fulfillment" USING btree ("deleted_at");

CREATE INDEX "IDX_fulfillment_id_-31ea43a" ON "public"."return_fulfillment" USING btree ("fulfillment_id");

CREATE INDEX "IDX_id_-31ea43a" ON "public"."return_fulfillment" USING btree ("id");

CREATE INDEX "IDX_return_id_-31ea43a" ON "public"."return_fulfillment" USING btree ("return_id");


DROP TABLE IF EXISTS "return_item";
CREATE TABLE "public"."return_item" (
    "id" text NOT NULL,
    "return_id" text NOT NULL,
    "reason_id" text,
    "item_id" text NOT NULL,
    "quantity" numeric NOT NULL,
    "raw_quantity" jsonb NOT NULL,
    "received_quantity" numeric DEFAULT '0' NOT NULL,
    "raw_received_quantity" jsonb NOT NULL,
    "note" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "damaged_quantity" numeric DEFAULT '0' NOT NULL,
    "raw_damaged_quantity" jsonb NOT NULL,
    CONSTRAINT "return_item_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_return_item_deleted_at" ON "public"."return_item" USING btree ("deleted_at");

CREATE INDEX "IDX_return_item_item_id" ON "public"."return_item" USING btree ("item_id");

CREATE INDEX "IDX_return_item_reason_id" ON "public"."return_item" USING btree ("reason_id");

CREATE INDEX "IDX_return_item_return_id" ON "public"."return_item" USING btree ("return_id");


DROP TABLE IF EXISTS "return_reason";
CREATE TABLE "public"."return_reason" (
    "id" character varying NOT NULL,
    "value" character varying NOT NULL,
    "label" character varying NOT NULL,
    "description" character varying,
    "metadata" jsonb,
    "parent_return_reason_id" character varying,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "return_reason_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_return_reason_value" ON "public"."return_reason" USING btree ("value");


DROP TABLE IF EXISTS "sales_channel";
CREATE TABLE "public"."sales_channel" (
    "id" text NOT NULL,
    "name" text NOT NULL,
    "description" text,
    "is_disabled" boolean DEFAULT false NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "sales_channel_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_sales_channel_deleted_at" ON "public"."sales_channel" USING btree ("deleted_at");


DROP TABLE IF EXISTS "sales_channel_stock_location";
CREATE TABLE "public"."sales_channel_stock_location" (
    "sales_channel_id" character varying(255) NOT NULL,
    "stock_location_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "sales_channel_stock_location_pkey" PRIMARY KEY ("sales_channel_id", "stock_location_id")
) WITH (oids = false);

CREATE INDEX "IDX_deleted_at_26d06f470" ON "public"."sales_channel_stock_location" USING btree ("deleted_at");

CREATE INDEX "IDX_id_26d06f470" ON "public"."sales_channel_stock_location" USING btree ("id");

CREATE INDEX "IDX_sales_channel_id_26d06f470" ON "public"."sales_channel_stock_location" USING btree ("sales_channel_id");

CREATE INDEX "IDX_stock_location_id_26d06f470" ON "public"."sales_channel_stock_location" USING btree ("stock_location_id");


DROP TABLE IF EXISTS "service_zone";
CREATE TABLE "public"."service_zone" (
    "id" text NOT NULL,
    "name" text NOT NULL,
    "metadata" jsonb,
    "fulfillment_set_id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "service_zone_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_service_zone_deleted_at" ON "public"."service_zone" USING btree ("deleted_at");

CREATE INDEX "IDX_service_zone_fulfillment_set_id" ON "public"."service_zone" USING btree ("fulfillment_set_id");

CREATE INDEX "IDX_service_zone_name_unique" ON "public"."service_zone" USING btree ("name");


DROP TABLE IF EXISTS "shipping_option";
CREATE TABLE "public"."shipping_option" (
    "id" text NOT NULL,
    "name" text NOT NULL,
    "price_type" text DEFAULT 'flat' NOT NULL,
    "service_zone_id" text NOT NULL,
    "shipping_profile_id" text,
    "provider_id" text,
    "data" jsonb,
    "metadata" jsonb,
    "shipping_option_type_id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "shipping_option_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "shipping_option_shipping_option_type_id_unique" UNIQUE ("shipping_option_type_id")
) WITH (oids = false);

CREATE INDEX "IDX_shipping_option_deleted_at" ON "public"."shipping_option" USING btree ("deleted_at");

CREATE INDEX "IDX_shipping_option_provider_id" ON "public"."shipping_option" USING btree ("provider_id");

CREATE INDEX "IDX_shipping_option_service_zone_id" ON "public"."shipping_option" USING btree ("service_zone_id");

CREATE INDEX "IDX_shipping_option_shipping_option_type_id" ON "public"."shipping_option" USING btree ("shipping_option_type_id");

CREATE INDEX "IDX_shipping_option_shipping_profile_id" ON "public"."shipping_option" USING btree ("shipping_profile_id");


DROP TABLE IF EXISTS "shipping_option_price_set";
CREATE TABLE "public"."shipping_option_price_set" (
    "shipping_option_id" character varying(255) NOT NULL,
    "price_set_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamptz(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamptz(0),
    CONSTRAINT "shipping_option_price_set_pkey" PRIMARY KEY ("shipping_option_id", "price_set_id")
) WITH (oids = false);

CREATE INDEX "IDX_deleted_at_ba32fa9c" ON "public"."shipping_option_price_set" USING btree ("deleted_at");

CREATE INDEX "IDX_id_ba32fa9c" ON "public"."shipping_option_price_set" USING btree ("id");

CREATE INDEX "IDX_price_set_id_ba32fa9c" ON "public"."shipping_option_price_set" USING btree ("price_set_id");

CREATE INDEX "IDX_shipping_option_id_ba32fa9c" ON "public"."shipping_option_price_set" USING btree ("shipping_option_id");


DROP TABLE IF EXISTS "shipping_option_rule";
CREATE TABLE "public"."shipping_option_rule" (
    "id" text NOT NULL,
    "attribute" text NOT NULL,
    "operator" text NOT NULL,
    "value" jsonb,
    "shipping_option_id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "shipping_option_rule_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_shipping_option_rule_deleted_at" ON "public"."shipping_option_rule" USING btree ("deleted_at");

CREATE INDEX "IDX_shipping_option_rule_shipping_option_id" ON "public"."shipping_option_rule" USING btree ("shipping_option_id");


DROP TABLE IF EXISTS "shipping_option_type";
CREATE TABLE "public"."shipping_option_type" (
    "id" text NOT NULL,
    "label" text NOT NULL,
    "description" text,
    "code" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "shipping_option_type_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_shipping_option_type_deleted_at" ON "public"."shipping_option_type" USING btree ("deleted_at");


DROP TABLE IF EXISTS "shipping_profile";
CREATE TABLE "public"."shipping_profile" (
    "id" text NOT NULL,
    "name" text NOT NULL,
    "type" text NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "shipping_profile_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_shipping_profile_deleted_at" ON "public"."shipping_profile" USING btree ("deleted_at");

CREATE INDEX "IDX_shipping_profile_name_unique" ON "public"."shipping_profile" USING btree ("name");


DROP TABLE IF EXISTS "stock_location";
CREATE TABLE "public"."stock_location" (
    "id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "name" text NOT NULL,
    "address_id" text,
    "metadata" jsonb,
    CONSTRAINT "stock_location_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_stock_location_deleted_at" ON "public"."stock_location" USING btree ("deleted_at");


DROP TABLE IF EXISTS "stock_location_address";
CREATE TABLE "public"."stock_location_address" (
    "id" text NOT NULL,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    "address_1" text NOT NULL,
    "address_2" text,
    "company" text,
    "city" text,
    "country_code" text NOT NULL,
    "phone" text,
    "province" text,
    "postal_code" text,
    "metadata" jsonb,
    CONSTRAINT "stock_location_address_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_stock_location_address_deleted_at" ON "public"."stock_location_address" USING btree ("deleted_at");


DROP TABLE IF EXISTS "store";
CREATE TABLE "public"."store" (
    "id" text NOT NULL,
    "name" text DEFAULT 'Medusa Store' NOT NULL,
    "default_sales_channel_id" text,
    "default_region_id" text,
    "default_location_id" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "store_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_store_deleted_at" ON "public"."store" USING btree ("deleted_at");


DROP TABLE IF EXISTS "store_currency";
CREATE TABLE "public"."store_currency" (
    "id" text NOT NULL,
    "currency_code" text NOT NULL,
    "is_default" boolean DEFAULT false NOT NULL,
    "store_id" text,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "store_currency_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_store_currency_deleted_at" ON "public"."store_currency" USING btree ("deleted_at");


DROP TABLE IF EXISTS "tax_provider";
CREATE TABLE "public"."tax_provider" (
    "id" text NOT NULL,
    "is_enabled" boolean DEFAULT true NOT NULL,
    CONSTRAINT "tax_provider_pkey" PRIMARY KEY ("id")
) WITH (oids = false);


DROP TABLE IF EXISTS "tax_rate";
CREATE TABLE "public"."tax_rate" (
    "id" text NOT NULL,
    "rate" real,
    "code" text NOT NULL,
    "name" text NOT NULL,
    "is_default" boolean DEFAULT false NOT NULL,
    "is_combinable" boolean DEFAULT false NOT NULL,
    "tax_region_id" text NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "created_by" text,
    "deleted_at" timestamptz,
    CONSTRAINT "tax_rate_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_single_default_region" ON "public"."tax_rate" USING btree ("tax_region_id");

CREATE INDEX "IDX_tax_rate_deleted_at" ON "public"."tax_rate" USING btree ("deleted_at");

CREATE INDEX "IDX_tax_rate_tax_region_id" ON "public"."tax_rate" USING btree ("tax_region_id");


DROP TABLE IF EXISTS "tax_rate_rule";
CREATE TABLE "public"."tax_rate_rule" (
    "id" text NOT NULL,
    "tax_rate_id" text NOT NULL,
    "reference_id" text NOT NULL,
    "reference" text NOT NULL,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "created_by" text,
    "deleted_at" timestamptz,
    CONSTRAINT "tax_rate_rule_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_tax_rate_rule_deleted_at" ON "public"."tax_rate_rule" USING btree ("deleted_at");

CREATE INDEX "IDX_tax_rate_rule_reference_id" ON "public"."tax_rate_rule" USING btree ("reference_id");

CREATE INDEX "IDX_tax_rate_rule_tax_rate_id" ON "public"."tax_rate_rule" USING btree ("tax_rate_id");

CREATE INDEX "IDX_tax_rate_rule_unique_rate_reference" ON "public"."tax_rate_rule" USING btree ("tax_rate_id", "reference_id");


DROP TABLE IF EXISTS "tax_region";
CREATE TABLE "public"."tax_region" (
    "id" text NOT NULL,
    "provider_id" text,
    "country_code" text NOT NULL,
    "province_code" text,
    "parent_id" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "created_by" text,
    "deleted_at" timestamptz,
    CONSTRAINT "tax_region_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_tax_region_deleted_at" ON "public"."tax_region" USING btree ("deleted_at");

CREATE INDEX "IDX_tax_region_parent_id" ON "public"."tax_region" USING btree ("parent_id");

CREATE INDEX "IDX_tax_region_unique_country_nullable_province" ON "public"."tax_region" USING btree ("country_code");

CREATE INDEX "IDX_tax_region_unique_country_province" ON "public"."tax_region" USING btree ("country_code", "province_code");


DROP TABLE IF EXISTS "user";
CREATE TABLE "public"."user" (
    "id" text NOT NULL,
    "first_name" text,
    "last_name" text,
    "email" text NOT NULL,
    "avatar_url" text,
    "metadata" jsonb,
    "created_at" timestamptz DEFAULT now() NOT NULL,
    "updated_at" timestamptz DEFAULT now() NOT NULL,
    "deleted_at" timestamptz,
    CONSTRAINT "user_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "IDX_user_deleted_at" ON "public"."user" USING btree ("deleted_at");

CREATE INDEX "IDX_user_email" ON "public"."user" USING btree ("email");


DROP TABLE IF EXISTS "workflow_execution";
CREATE TABLE "public"."workflow_execution" (
    "id" character varying NOT NULL,
    "workflow_id" character varying NOT NULL,
    "transaction_id" character varying NOT NULL,
    "execution" jsonb,
    "context" jsonb,
    "state" character varying NOT NULL,
    "created_at" timestamp DEFAULT now() NOT NULL,
    "updated_at" timestamp DEFAULT now() NOT NULL,
    "deleted_at" timestamp,
    CONSTRAINT "IDX_workflow_execution_id" UNIQUE ("id"),
    CONSTRAINT "PK_workflow_execution_workflow_id_transaction_id" PRIMARY KEY ("workflow_id", "transaction_id")
) WITH (oids = false);

CREATE INDEX "IDX_workflow_execution_state" ON "public"."workflow_execution" USING btree ("state");

CREATE INDEX "IDX_workflow_execution_transaction_id" ON "public"."workflow_execution" USING btree ("transaction_id");

CREATE INDEX "IDX_workflow_execution_workflow_id" ON "public"."workflow_execution" USING btree ("workflow_id");


ALTER TABLE ONLY "public"."application_method_buy_rules" ADD CONSTRAINT "application_method_buy_rules_application_method_id_foreign" FOREIGN KEY (application_method_id) REFERENCES promotion_application_method(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."application_method_buy_rules" ADD CONSTRAINT "application_method_buy_rules_promotion_rule_id_foreign" FOREIGN KEY (promotion_rule_id) REFERENCES promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."application_method_target_rules" ADD CONSTRAINT "application_method_target_rules_application_method_id_foreign" FOREIGN KEY (application_method_id) REFERENCES promotion_application_method(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."application_method_target_rules" ADD CONSTRAINT "application_method_target_rules_promotion_rule_id_foreign" FOREIGN KEY (promotion_rule_id) REFERENCES promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."capture" ADD CONSTRAINT "capture_payment_id_foreign" FOREIGN KEY (payment_id) REFERENCES payment(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart" ADD CONSTRAINT "cart_billing_address_id_foreign" FOREIGN KEY (billing_address_id) REFERENCES cart_address(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;
ALTER TABLE ONLY "public"."cart" ADD CONSTRAINT "cart_shipping_address_id_foreign" FOREIGN KEY (shipping_address_id) REFERENCES cart_address(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart_line_item" ADD CONSTRAINT "cart_line_item_cart_id_foreign" FOREIGN KEY (cart_id) REFERENCES cart(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart_line_item_adjustment" ADD CONSTRAINT "cart_line_item_adjustment_item_id_foreign" FOREIGN KEY (item_id) REFERENCES cart_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart_line_item_tax_line" ADD CONSTRAINT "cart_line_item_tax_line_item_id_foreign" FOREIGN KEY (item_id) REFERENCES cart_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart_shipping_method" ADD CONSTRAINT "cart_shipping_method_cart_id_foreign" FOREIGN KEY (cart_id) REFERENCES cart(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart_shipping_method_adjustment" ADD CONSTRAINT "cart_shipping_method_adjustment_shipping_method_id_foreign" FOREIGN KEY (shipping_method_id) REFERENCES cart_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."cart_shipping_method_tax_line" ADD CONSTRAINT "cart_shipping_method_tax_line_shipping_method_id_foreign" FOREIGN KEY (shipping_method_id) REFERENCES cart_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."customer_address" ADD CONSTRAINT "customer_address_customer_id_foreign" FOREIGN KEY (customer_id) REFERENCES customer(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."customer_group_customer" ADD CONSTRAINT "customer_group_customer_customer_group_id_foreign" FOREIGN KEY (customer_group_id) REFERENCES customer_group(id) ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."customer_group_customer" ADD CONSTRAINT "customer_group_customer_customer_id_foreign" FOREIGN KEY (customer_id) REFERENCES customer(id) ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."fulfillment" ADD CONSTRAINT "fulfillment_delivery_address_id_foreign" FOREIGN KEY (delivery_address_id) REFERENCES fulfillment_address(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."fulfillment" ADD CONSTRAINT "fulfillment_provider_id_foreign" FOREIGN KEY (provider_id) REFERENCES fulfillment_provider(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;
ALTER TABLE ONLY "public"."fulfillment" ADD CONSTRAINT "fulfillment_shipping_option_id_foreign" FOREIGN KEY (shipping_option_id) REFERENCES shipping_option(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."fulfillment_item" ADD CONSTRAINT "fulfillment_item_fulfillment_id_foreign" FOREIGN KEY (fulfillment_id) REFERENCES fulfillment(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."fulfillment_label" ADD CONSTRAINT "fulfillment_label_fulfillment_id_foreign" FOREIGN KEY (fulfillment_id) REFERENCES fulfillment(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."geo_zone" ADD CONSTRAINT "geo_zone_service_zone_id_foreign" FOREIGN KEY (service_zone_id) REFERENCES service_zone(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."inventory_level" ADD CONSTRAINT "inventory_level_inventory_item_id_foreign" FOREIGN KEY (inventory_item_id) REFERENCES inventory_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."notification" ADD CONSTRAINT "notification_provider_id_foreign" FOREIGN KEY (provider_id) REFERENCES notification_provider(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order" ADD CONSTRAINT "order_billing_address_id_foreign" FOREIGN KEY (billing_address_id) REFERENCES order_address(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."order" ADD CONSTRAINT "order_shipping_address_id_foreign" FOREIGN KEY (shipping_address_id) REFERENCES order_address(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_change" ADD CONSTRAINT "order_change_order_id_foreign" FOREIGN KEY (order_id) REFERENCES "order"(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_change_action" ADD CONSTRAINT "order_change_action_order_change_id_foreign" FOREIGN KEY (order_change_id) REFERENCES order_change(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_item" ADD CONSTRAINT "order_item_item_id_foreign" FOREIGN KEY (item_id) REFERENCES order_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."order_item" ADD CONSTRAINT "order_item_order_id_foreign" FOREIGN KEY (order_id) REFERENCES "order"(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_line_item" ADD CONSTRAINT "order_line_item_totals_id_foreign" FOREIGN KEY (totals_id) REFERENCES order_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_line_item_adjustment" ADD CONSTRAINT "order_line_item_adjustment_item_id_foreign" FOREIGN KEY (item_id) REFERENCES order_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_line_item_tax_line" ADD CONSTRAINT "order_line_item_tax_line_item_id_foreign" FOREIGN KEY (item_id) REFERENCES order_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_shipping" ADD CONSTRAINT "order_shipping_order_id_foreign" FOREIGN KEY (order_id) REFERENCES "order"(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_shipping_method_adjustment" ADD CONSTRAINT "order_shipping_method_adjustment_shipping_method_id_foreign" FOREIGN KEY (shipping_method_id) REFERENCES order_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_shipping_method_tax_line" ADD CONSTRAINT "order_shipping_method_tax_line_shipping_method_id_foreign" FOREIGN KEY (shipping_method_id) REFERENCES order_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."order_transaction" ADD CONSTRAINT "order_transaction_order_id_foreign" FOREIGN KEY (order_id) REFERENCES "order"(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."payment" ADD CONSTRAINT "payment_payment_collection_id_foreign" FOREIGN KEY (payment_collection_id) REFERENCES payment_collection(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."payment_collection_payment_providers" ADD CONSTRAINT "payment_collection_payment_providers_payment_coll_aa276_foreign" FOREIGN KEY (payment_collection_id) REFERENCES payment_collection(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."payment_collection_payment_providers" ADD CONSTRAINT "payment_collection_payment_providers_payment_provider_id_foreig" FOREIGN KEY (payment_provider_id) REFERENCES payment_provider(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."price" ADD CONSTRAINT "price_price_list_id_foreign" FOREIGN KEY (price_list_id) REFERENCES price_list(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."price" ADD CONSTRAINT "price_price_set_id_foreign" FOREIGN KEY (price_set_id) REFERENCES price_set(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."price_list_rule" ADD CONSTRAINT "price_list_rule_price_list_id_foreign" FOREIGN KEY (price_list_id) REFERENCES price_list(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."price_rule" ADD CONSTRAINT "price_rule_price_id_foreign" FOREIGN KEY (price_id) REFERENCES price(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product" ADD CONSTRAINT "product_collection_id_foreign" FOREIGN KEY (collection_id) REFERENCES product_collection(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;
ALTER TABLE ONLY "public"."product" ADD CONSTRAINT "product_type_id_foreign" FOREIGN KEY (type_id) REFERENCES product_type(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_category" ADD CONSTRAINT "product_category_parent_category_id_foreign" FOREIGN KEY (parent_category_id) REFERENCES product_category(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_category_product" ADD CONSTRAINT "product_category_product_product_category_id_foreign" FOREIGN KEY (product_category_id) REFERENCES product_category(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."product_category_product" ADD CONSTRAINT "product_category_product_product_id_foreign" FOREIGN KEY (product_id) REFERENCES product(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_images" ADD CONSTRAINT "product_images_image_id_foreign" FOREIGN KEY (image_id) REFERENCES image(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."product_images" ADD CONSTRAINT "product_images_product_id_foreign" FOREIGN KEY (product_id) REFERENCES product(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_option" ADD CONSTRAINT "product_option_product_id_foreign" FOREIGN KEY (product_id) REFERENCES product(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_option_value" ADD CONSTRAINT "product_option_value_option_id_foreign" FOREIGN KEY (option_id) REFERENCES product_option(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_tags" ADD CONSTRAINT "product_tags_product_id_foreign" FOREIGN KEY (product_id) REFERENCES product(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."product_tags" ADD CONSTRAINT "product_tags_product_tag_id_foreign" FOREIGN KEY (product_tag_id) REFERENCES product_tag(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_variant" ADD CONSTRAINT "product_variant_product_id_foreign" FOREIGN KEY (product_id) REFERENCES product(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."product_variant_option" ADD CONSTRAINT "product_variant_option_option_value_id_foreign" FOREIGN KEY (option_value_id) REFERENCES product_option_value(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."product_variant_option" ADD CONSTRAINT "product_variant_option_variant_id_foreign" FOREIGN KEY (variant_id) REFERENCES product_variant(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."promotion" ADD CONSTRAINT "promotion_campaign_id_foreign" FOREIGN KEY (campaign_id) REFERENCES promotion_campaign(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."promotion_application_method" ADD CONSTRAINT "promotion_application_method_promotion_id_foreign" FOREIGN KEY (promotion_id) REFERENCES promotion(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."promotion_campaign_budget" ADD CONSTRAINT "promotion_campaign_budget_campaign_id_foreign" FOREIGN KEY (campaign_id) REFERENCES promotion_campaign(id) ON UPDATE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."promotion_promotion_rule" ADD CONSTRAINT "promotion_promotion_rule_promotion_id_foreign" FOREIGN KEY (promotion_id) REFERENCES promotion(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."promotion_promotion_rule" ADD CONSTRAINT "promotion_promotion_rule_promotion_rule_id_foreign" FOREIGN KEY (promotion_rule_id) REFERENCES promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."promotion_rule_value" ADD CONSTRAINT "promotion_rule_value_promotion_rule_id_foreign" FOREIGN KEY (promotion_rule_id) REFERENCES promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."provider_identity" ADD CONSTRAINT "provider_identity_auth_identity_id_foreign" FOREIGN KEY (auth_identity_id) REFERENCES auth_identity(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."refund" ADD CONSTRAINT "refund_payment_id_foreign" FOREIGN KEY (payment_id) REFERENCES payment(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."region_country" ADD CONSTRAINT "region_country_region_id_foreign" FOREIGN KEY (region_id) REFERENCES region(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."reservation_item" ADD CONSTRAINT "reservation_item_inventory_item_id_foreign" FOREIGN KEY (inventory_item_id) REFERENCES inventory_item(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."return_reason" ADD CONSTRAINT "return_reason_parent_return_reason_id_foreign" FOREIGN KEY (parent_return_reason_id) REFERENCES return_reason(id) NOT DEFERRABLE;

ALTER TABLE ONLY "public"."service_zone" ADD CONSTRAINT "service_zone_fulfillment_set_id_foreign" FOREIGN KEY (fulfillment_set_id) REFERENCES fulfillment_set(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."shipping_option" ADD CONSTRAINT "shipping_option_provider_id_foreign" FOREIGN KEY (provider_id) REFERENCES fulfillment_provider(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;
ALTER TABLE ONLY "public"."shipping_option" ADD CONSTRAINT "shipping_option_service_zone_id_foreign" FOREIGN KEY (service_zone_id) REFERENCES service_zone(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."shipping_option" ADD CONSTRAINT "shipping_option_shipping_option_type_id_foreign" FOREIGN KEY (shipping_option_type_id) REFERENCES shipping_option_type(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."shipping_option" ADD CONSTRAINT "shipping_option_shipping_profile_id_foreign" FOREIGN KEY (shipping_profile_id) REFERENCES shipping_profile(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."shipping_option_rule" ADD CONSTRAINT "shipping_option_rule_shipping_option_id_foreign" FOREIGN KEY (shipping_option_id) REFERENCES shipping_option(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."stock_location" ADD CONSTRAINT "stock_location_address_id_foreign" FOREIGN KEY (address_id) REFERENCES stock_location_address(id) ON UPDATE CASCADE ON DELETE SET NULL NOT DEFERRABLE;

ALTER TABLE ONLY "public"."store_currency" ADD CONSTRAINT "store_currency_store_id_foreign" FOREIGN KEY (store_id) REFERENCES store(id) ON UPDATE CASCADE ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."tax_rate" ADD CONSTRAINT "FK_tax_rate_tax_region_id" FOREIGN KEY (tax_region_id) REFERENCES tax_region(id) ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."tax_rate_rule" ADD CONSTRAINT "FK_tax_rate_rule_tax_rate_id" FOREIGN KEY (tax_rate_id) REFERENCES tax_rate(id) ON DELETE CASCADE NOT DEFERRABLE;

ALTER TABLE ONLY "public"."tax_region" ADD CONSTRAINT "FK_tax_region_parent_id" FOREIGN KEY (parent_id) REFERENCES tax_region(id) ON DELETE CASCADE NOT DEFERRABLE;
ALTER TABLE ONLY "public"."tax_region" ADD CONSTRAINT "FK_tax_region_provider_id" FOREIGN KEY (provider_id) REFERENCES tax_provider(id) ON DELETE SET NULL NOT DEFERRABLE;

-- 2025-01-09 01:46:00.073091+00
